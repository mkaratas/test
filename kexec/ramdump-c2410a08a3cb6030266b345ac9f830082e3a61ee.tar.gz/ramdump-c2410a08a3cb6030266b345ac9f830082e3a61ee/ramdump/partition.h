#pragma once

#define PARTITION_ID_S1BOOT   0x01
#define PARTITION_ID_TA       0x02
#define PARTITION_ID_KERNEL   0x03
#define PARTITION_ID_SYSTEM   0x04
#define PARTITION_ID_AMSS     0x05
#define PARTITION_ID_AMSSFS   0x06
#define PARTITION_ID_FOTA_UA  0x07
#define PARTITION_ID_ADSP     0x08
#define PARTITION_ID_USERDATA 0x09
#define PARTITION_ID_FOTA0    0x0B
#define PARTITION_ID_FOTA1    0x0C
#define PARTITION_ID_MDMLOG   0x0D
#define PARTITION_ID_RECOVER  0x0E
#define PARTITION_ID_CACHE    0x0F

typedef struct {
  uint32 id;
  uint32 attr;
  uint32 start;
  uint32 len;
} partition_t;

int                partition_init(void);
const partition_t *partition_get(uint32 id);
