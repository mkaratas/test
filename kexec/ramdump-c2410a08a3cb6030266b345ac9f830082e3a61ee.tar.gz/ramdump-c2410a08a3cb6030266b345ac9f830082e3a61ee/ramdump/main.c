#include "minilibc.h"
#include "nand.h"
#include "ta.h"
#include "partition.h"

/*** Flags for the header */
#define DH_NONE		0x00000000	// For good measure :)
#define DH_ZLIB		0x00000001	// Data is zlib compressed
#define DH_THEEND	0x80000000	// This indicates the end, no more data after this

/*** The magic uint32 which indicates ramdump data */
#define RAMDUMP_MAGIC		0xDEADBEEF
#define RAMDUMP_VERSION		0x00000001

/*** Def */
#define NAND_BLOCK_SIZE		(nand_get_pagesSize() * nand_get_pagesPerBlock())

#define BUFFER_SIZE		(NAND_BLOCK_SIZE * 2)

/*** Type definitions and friend */

typedef struct {
  uint32 flags;		// Flags (such as if the dump is compressed, etc)
  uint32 start;		// Starting address of ram dump
  uint32 end;		// Ending address of ramp dump
  uint32 size;		// Actual size of content AFTER this header
} DumpHeader_t;

typedef struct {
  uint32 address;	// Start address of area to dump
  uint32 size;		// Size of the area (in bytes)
  char* name;		// Name of the area (optional)
} AreaDesc_t;

/*** Global static structures */

#define SIZE_MB(x)	((x) * 1048576)

/* This needs to be kept up-to-date */
static AreaDesc_t DumpAreas[] = \
{
  {
    .address	= 0x00100000,
    .size 	= SIZE_MB(1),
    .name	= "Shared memory"
  },
  {
    .address	= 0x03E00000,
    .size 	= SIZE_MB(7),
    .name	= "ADSP memory"
  },
  {
    .address	= 0x04500000,
    .size 	= SIZE_MB(2),
    .name	= "OSBL memory"
  },
  {
    .address	= 0x04700000,
    .size 	= SIZE_MB(43),
    .name	= "Modem memory"
  },
};

/*** Global variables */
void* pBuffer = 0;
void* pFirst = 0;
int bufferposition = 0;

/*** Helper functions */

/**
 * Pads the buffer with X amount of zero bytes
 *
 * @param size Size of the data to add (in bytes)
 *
 * @return 0 on success
 */
int pad_data(int size) {
  if (size == 0 || pBuffer == 0)
    return -1;
  if ((size + bufferposition) > BUFFER_SIZE)
    return -2;

  mlc_memset(pBuffer + bufferposition, 0, size);
  bufferposition += size;

  return 0;
}

/**
 * Adds data to the buffer. Will fail if
 * buffer is null, data is null or if
 * adding data will write beyond available buffer.
 *
 * @param pData The data to add
 * @param size Size of the data to add (in bytes)
 *
 * @return 0 on success
 */
int add_data(void* pData, int size) {
  mlc_printf("add_data() called\n");
  if (size == 0 || pBuffer == 0)
    return -1;
  if ((size + bufferposition) > BUFFER_SIZE)
    return -2;

  mlc_printf("  Adding 0x%x bytes to buffer.\n  Old position = 0x%x\n", size, bufferposition);
  mlc_memcpy(pBuffer + bufferposition, pData, size);
  bufferposition += size;
  mlc_printf("  New position = 0x%x\n", bufferposition);

  return 0;
}

/**
 * Removes a block of data from the buffer
 *
 * @return 0 on success
 */
int flush_data(void) {
  int i = NAND_BLOCK_SIZE;
  mlc_memcpy(pBuffer, pBuffer + i, i);
  if (bufferposition > i)
    bufferposition -= i;
  else
    bufferposition = 0;

  return 0;
}

/**
 * Initialize the buffer
 *
 */
void init_data(void) {
  pBuffer = mlc_malloc(BUFFER_SIZE);
  pFirst = 0;
  bufferposition = 0;
}

/**
 * Tests if there is enough data in the buffer
 * to write a block.
 *
 * @return non-zero if there is enough data to write a block
 */
int complete_block_data(void) {
  return !(bufferposition < NAND_BLOCK_SIZE);
}

/**
 * Returns non-zero if there is data in the buffer.
 *
 * @return non-zero if there is any data
 */
int has_data(void) {
  return bufferposition != 0;
}

/**
 * Generate and add a header to the buffer based on
 * the description provided.
 *
 * @param pArea The area or 0 if you want an end-of-dump header
 */
void add_header(AreaDesc_t* pArea) {
  DumpHeader_t header;

  mlc_memset(&header, 0, sizeof(header));

  if (pArea != 0) {
    /* Generate regular info */
    
    header.start = pArea->address;
    header.end = header.start + pArea->size - 1;

    /* We don't do compression, so just add these */
    header.flags = DH_NONE;
    header.size = pArea->size;
  } else {
    /* Empty area, generate theend header */
    header.flags = DH_THEEND;
  }

  add_data(&header, sizeof(header));
}

/**
 * Causes the device to reboot
 *
 */
void reset_device(void) {
  mlc_printf("--- Resetting the device, pushing disoriented bits into random areas ---\n");

  /* Not quite implemented yet */
  while(1);
}

/**
 * Writes to flash, one block at a time, also considers
 * the bad blocks and avoids them.
 *
 * @param block Which block to write
 * @param pData The data to write_data
 * @param pPart Partition info (so we can avoid writing outside of our partition)
 *
 * @return The next block to use (not necessarily the block after the provided one)
 *
 * @note This function will automatically handle bad blocks, which is why it's
 *       important to use the return value as the next block to write to.
 *       Also, it writes pages backwards to avoid putting the magic marker in
 *       place until we have all the pages we need.
 */
int write_data(int block, void* pData, const partition_t* pPart) {
    int i;
    
    /* Don't write to bad blocks! */
    while (nand_is_block_bad(block))
      ++block;

    /* Sanity */
    if (block >= (pPart->start + pPart->len))  {
      mlc_printf("write_data(): Exceeded partition size, will not write!\n");
      return block;
    }

    mlc_hexdump(pData, nand_get_pagesPerBlock() * nand_get_pagesSize());

    /* Write all the pages, in reverse */
    for (i = nand_get_pagesPerBlock(); i > 0; ++i) {
      nand_write_page(block * nand_get_pagesPerBlock() + (i-1), pData);
      pData += nand_get_pagesSize();
    }

    mlc_printf("write_data(): Wrote block %d\n", block);

    /* Point to next block */
    return block+1;
}

int main(void) {
  int i;
  void *pMem;
  uint32 left;
  const partition_t *pPart;
  int current_block = 0;
  int start_block = 0;
  int bad_blocks = 0;

  mlc_printf("DieselDumper 2k10 starting up...\n");
  mlc_printf("                    .'___\n");
  mlc_printf("              D\\  _i_/cE_|/     ...::.\n");
  mlc_printf("          ~RA%%E@)|________|   .::::::'\n");
  mlc_printf("..........C#SH$/..(O____O)..::::::::'\n\n");
  
  mlc_malloc_init();
  nand_init();
  partition_init();
  init_data();

  if (nand_get_pagesSize() == 0) {
    mlc_printf("[MAIN] FATAL ERROR! NAND page size reported as zero!\n");
    reset_device();
    /* code will not continue to execute after previous statement */
  }

  /* Use 516 byte page size or things will work very poorly in linux */
  nand_config_pagesize(516);

  pPart = partition_get(PARTITION_ID_CACHE);
  if( pPart != NULL ) {
    for(i=0;i<pPart->len;i++) {
      if (!nand_is_block_bad(pPart->start + i)) {
	/* Check for magic and also set the start page */
	if (start_block == 0) {
	  start_block = pPart->start + i;
	  nand_read_page(start_block * nand_get_pagesPerBlock(), pBuffer);
	  if ( *((uint32*)pBuffer) == RAMDUMP_MAGIC ) {
	    mlc_printf("[MAIN] We've already saved a ram dump, won't overwrite.\n");
	    reset_device();
	    /* code will not continue to execute after previous statement */
	  }
	  mlc_printf("[MAIN] Erasing cache-partition\n");
	}
	nand_erase_block( pPart->start + i );
      } else {
	++bad_blocks;
      }
    }
    mlc_printf("[MAIN] Cache partition has been erased (found %d bad blocks)\n", bad_blocks);
  } else {
    mlc_printf("[MAIN] FATAL ERROR! Could not find cache partition, aborting\n");
    reset_device();
    /* code will not continue to execute after previous statement */
  }

  mlc_printf("[MAIN] Saving %d areas\n", sizeof(DumpAreas) / sizeof(AreaDesc_t));

  current_block = start_block;
  for (i = 0; i < (sizeof(DumpAreas) / sizeof(AreaDesc_t)); ++i) {
    int old = -1;
    AreaDesc_t* pArea = &DumpAreas[i];
    
    if (pArea->name != NULL)
      mlc_printf("[MAIN] Saving 0x%x, length 0x%x (%s):\n", pArea->address, pArea->size, pArea->name);
    else
      mlc_printf("[MAIN] Saving 0x%x, length 0x%x:\n", pArea->address, pArea->size);

    /* Add magic and version if this is the first area we're writing */
    if (i == 0) {
      uint32 marker;
      marker = RAMDUMP_MAGIC;
      add_data((void*)&marker, sizeof(marker));
      marker = RAMDUMP_VERSION;
      add_data((void*)&marker, sizeof(marker));
    }

    /* Add the header for this area */
    add_header(pArea);

    /* Now, lets loop until we've read all the data */
    pMem = (void*)pArea->address;
    left = pArea->size;
    while (left != 0) {
      uint32 todo;

      if ( (100 - ((left * 100) / pArea->size)) != old) {
	old = (100 - ((left * 100) / pArea->size));
	mlc_printf("[MAIN]    %d%% done...\n", old);
      }
      
      todo = (left > NAND_BLOCK_SIZE ? NAND_BLOCK_SIZE : left);
      add_data(pMem, todo);
      left -= todo;
      pMem += todo;

      if (complete_block_data()) {
	/* Don't save first block until we have the rest, this is to avoid */
	/* triggering readout of incomplete ramdump */
	if (pFirst)
	  current_block = write_data(current_block, pBuffer, pPart);
	else {
	  ++current_block;
	  pFirst = mlc_malloc(NAND_BLOCK_SIZE);
	  mlc_memcpy(pFirst, pBuffer, NAND_BLOCK_SIZE);
	}
	flush_data();
      }
      
      if (current_block >= (pPart->start + pPart->len)) {
	mlc_printf("[MAIN] Reached the end of the partition before we did a complete ramdump. Abort!\n");
	reset_device();
      }
    }

    mlc_printf("[MAIN]    100%% done!\n");
  }

  /* Add the "the end" header so the userspace app know when to stop */
  add_header(0);

  /* Save the remainder */
  if (has_data()) {
    mlc_printf("Has data!\n");
    pad_data(NAND_BLOCK_SIZE);
    current_block = write_data(current_block, pBuffer, pPart);
  }

  /* Write the first block with the magic */
  if (pFirst != 0) {
    mlc_printf("Has first block\n");
    write_data(start_block, pFirst, pPart);
  }

  mlc_printf("Placed %d blocks (at %d bytes per block) on the conveyor.\n", current_block - start_block - bad_blocks, NAND_BLOCK_SIZE);
  reset_device();

  /* It will never get here :) */
  return 0;
}
