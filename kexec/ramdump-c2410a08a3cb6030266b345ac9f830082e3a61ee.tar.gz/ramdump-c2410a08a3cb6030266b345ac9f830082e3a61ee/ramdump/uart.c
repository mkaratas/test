#include "uart.h"
#include "io.h"

#define UART_BASE        0xacc00000
#define UART_TF          0x000C
#define UART_SR          0x0008
#define UART_SR_RX_READY (1 << 0)
#define UART_SR_TX_READY (1 << 2)

#define urd(a) readl(UART_BASE + (a))
#define uwr(v,a) writel(v, UART_BASE + (a))

int uart_putc(char c)
{
  while (!(urd(UART_SR) & UART_SR_TX_READY)) ;
  uwr(c, UART_TF);
  return 0;
}
