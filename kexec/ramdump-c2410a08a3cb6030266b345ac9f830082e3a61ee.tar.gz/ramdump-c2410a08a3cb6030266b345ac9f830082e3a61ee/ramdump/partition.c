#include "types.h"
#include "partition.h"
#include "minilibc.h"

#define BIAI_BASE 0x00080000
#define BIAI_INFO_HEADER_COUNT (64)

#define BIAI_ID_PARTITION        0
#define FLASH_NUM_PART_ENTRIES  16

typedef struct {
  uint32 id;
  uint32 attr;
  uint32 startb;
  uint32 sizeb;
} biai_partition_t;

typedef struct  {
  uint32 id;
  uint32 size;
  uint32 offset;
} biai_info_header_t;

static biai_info_header_t *biai_get_item(uint32 id, void **data)
{
  biai_info_header_t *hi;
  int i;

  hi = (biai_info_header_t*)BIAI_BASE;

  for (i = 0; i < BIAI_INFO_HEADER_COUNT; i++) {
    if (hi[i].id == id) {
      if (data != NULL)
        *data = (void*)(BIAI_BASE + 0x300 + hi[i].offset);
      return &hi[i];
    }
  }

  return NULL;
}

int partition_init(void) {
  biai_partition_t   *part;
  biai_info_header_t *header;
  int iNumPartitions,i;
  
  header = biai_get_item(BIAI_ID_PARTITION,(void**)&part);
  iNumPartitions = header->size / sizeof(biai_partition_t);

  mlc_printf("[PART] BIAI Partition dump\n");
  for(i=0;i<iNumPartitions;i++) {
    mlc_printf("[PART] Part%i: id=%i, attr=0x%x, startb=0x%x, sizeb=0x%x\n",i,part[i].id,part[i].attr,part[i].startb,part[i].sizeb);
  }

  return 0;
}

static partition_t parts[] = { 
  { .id = PARTITION_ID_S1BOOT, .attr = 0x00000022, .start = 0x00000000, .len = 0x00000001 },
  { .id = PARTITION_ID_TA    , .attr = 0x00000001, .start = 0x00000008, .len = 0x00000008 },
  { .id = PARTITION_ID_ADSP  , .attr = 0x00000022, .start = 0x00000110, .len = 0x00000032 },
  { .id = PARTITION_ID_AMSS  , .attr = 0x00000022, .start = 0x00000010, .len = 0x000000d0 },
  { .id = PARTITION_ID_AMSSFS, .attr = 0x40000001, .start = 0x000000e0, .len = 0x00000030 },
  { .id = PARTITION_ID_KERNEL, .attr = 0x80000022, .start = 0x00000142, .len = 0x0000002b },
  { .id = PARTITION_ID_CACHE , .attr = 0xc0000001, .start = 0x000004ad, .len = 0x000001ce },
  { .id = 0,.attr=0,.start=0,.len=0 } 
};

const partition_t *partition_get(uint32 id) {
  int i;

  i = 0;
  while( parts[i].id ) {
    if( parts[i].id == id )
      return &parts[i];
    i++;
  }

  return NULL;
}
