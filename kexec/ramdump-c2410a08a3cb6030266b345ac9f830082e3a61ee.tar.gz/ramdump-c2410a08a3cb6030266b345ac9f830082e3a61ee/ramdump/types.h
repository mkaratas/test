#pragma once

typedef unsigned int   uint32;
typedef unsigned short uint16;
typedef unsigned char  uint8;
typedef   signed int    int32;
typedef   signed short  int16;
typedef   signed char   int8;

typedef unsigned long   size_t;
typedef unsigned long   ssize_t;
typedef unsigned long   ptrdiff_t;
typedef unsigned char   boolean;

#undef NULL
#define NULL ((void*)0x0)

#undef FALSE
#define FALSE 0
#undef TRUE
#define TRUE (!FALSE)
