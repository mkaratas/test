#pragma once

#include "types.h"

#define REG32(addr) ((volatile uint32 *)(addr))

#define writel(v, a) (*REG32(a) = (v))
#define readl(a) (*REG32(a))
