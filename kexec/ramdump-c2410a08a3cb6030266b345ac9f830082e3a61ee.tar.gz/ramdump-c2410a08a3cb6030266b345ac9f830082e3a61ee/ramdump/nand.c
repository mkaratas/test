#include "io.h"
#include "minilibc.h"

#define MSM_NAND_BASE 0xA0200000

#define NAND_REG_FLASH_CMD         (MSM_NAND_BASE+0x00)
#define NAND_REG_ADDR0             (MSM_NAND_BASE+0x04)
#define NAND_REG_ADDR1             (MSM_NAND_BASE+0x08)
#define NAND_REG_FLASH_CHIP_SELECT (MSM_NAND_BASE+0x0C)
#define NANDC_REG_EXEC_CMD         (MSM_NAND_BASE+0x10)
#define NAND_REG_FLASH_STATUS      (MSM_NAND_BASE+0x14)
#define NANDC_REG_BUFFER_STATUS    (MSM_NAND_BASE+0x18)
#define NAND_REG_DEV0_CFG0         (MSM_NAND_BASE+0x20+0x00)
#define NAND_REG_DEV1_CFG0         (MSM_NAND_BASE+0x20+0x10)
#define NAND_REG_DEV0_CFG1         (MSM_NAND_BASE+0x24+0x00)
#define NAND_REG_DEV1_CFG1         (MSM_NAND_BASE+0x24+0x10)
#define NAND_REG_FLASH_READ_ID     (MSM_NAND_BASE+0x40)
#define NAND_REG_FLASH_READ_STATUS (MSM_NAND_BASE+0x44)

#define NAND_REG_FLASH_BUFFER      (MSM_NAND_BASE+0x100)

#define NAND_CMD_PAGE_READ           0x02
#define NAND_CMD_PAGE_READ_ECC       0x03
#define NAND_CMD_PAGE_READ_ECC_SPARE 0x04
#define NAND_CMD_PAGE_PROGRAM        0x06
#define NAND_CMD_PAGE_PROGRAM_ECC    0x07
#define NAND_CMD_BLOCK_ERASE         0x0A
#define NAND_CMD_FETCH_ID            0x0B

static struct {
  uint32 uPagesize;
  uint32 uPagesperblock;
  uint32 bIsWide;
  uint32 uTotalBlocks;
  uint32 uCWperPage;
} chip_info; 

#define VERBOSE_LOGGING 0

static void flash_wait_for_idle(void) {
  uint32 status;

  status = readl(NAND_REG_FLASH_STATUS);
  while( (status & 0xF) != 0x00 ) {
    status = readl(NAND_REG_FLASH_STATUS);
  }
}

static uint32 flash_read_id(void) {
  uint32 id;

  flash_wait_for_idle();

  writel( NAND_CMD_FETCH_ID, NAND_REG_FLASH_CMD );
  writel( 0x00000001, NANDC_REG_EXEC_CMD );
  flash_wait_for_idle();

  id = readl(NAND_REG_FLASH_READ_ID);

  if( id == 0x55d1b32c ) { /* 8Gb x16 Micron */
    chip_info.uPagesize      = 2048;
    chip_info.uPagesperblock = 64;
    chip_info.bIsWide        = 1;
    chip_info.uTotalBlocks   = 8192;
    chip_info.uCWperPage     = chip_info.uPagesize / 512;
  } else {
    return -1;
  }

  return id;
}

void flash_dump_status(void) {
  uint32 status;
  char *pzOper[] = { "Idle state", "Abort transaction", 
		     "Page read", "Page read ECC", "Page read ECC+Spare",
		     "Sequential page read",
		     "Program page", "Program page ECC", "Reserved programming", "Program page with spare",
		     "Block erase", "Fetch ID", "Check status", "Reset device",
		     "Reserved_programming","Reserved_programming" };
  char *pzBsy[] = { "External flash is busy", "External flash is ready" };

  status = readl( NAND_REG_FLASH_STATUS );
  
  mlc_printf("--[ NAND_FLASH_STATUS Dump ]--\n");
  mlc_printf("Oper_Status  : %s\n",pzOper[status&0xF]);
  mlc_printf("OP_Err       : %i\n",(status>>4)&1);
  mlc_printf("Ready_Bsy_N  : %s\n",pzBsy[(status>>5)&1]);
  mlc_printf("Codeword_Cntr: %i\n",(status>>12)&0xF);
}

int nand_is_block_bad(uint32 block) {
  uint32 page;
  uint32 status;
  int i;

  flash_wait_for_idle();

  page = block * chip_info.uPagesperblock;
  //  mlc_printf("%s: Page=%u\n",__func__,page);

  /* Addressing */
  writel( (page&0xFFFF)<<16, NAND_REG_ADDR0 ); /* [15:0] = Always 0, [31:16] = Low 16 bits of page# to read */
  writel( page >> 16, NAND_REG_ADDR1 ); /* Upper 32 bits of page# to read */
  writel( 0x00000000, NAND_REG_FLASH_CHIP_SELECT );

  writel( NAND_CMD_PAGE_READ_ECC | (1<<4) | (1<<5), NAND_REG_FLASH_CMD );

  for(i=0;i<4;i++) { /* Loop through all codewords */
    writel( 0x00000001, NANDC_REG_EXEC_CMD );
    flash_wait_for_idle();
  }
  
#if 0
  status = readl( NAND_REG_FLASH_STATUS );
  if( (status & (1<<4)) ||   /* Operation error (Uncorrectable ECC) */
      (status & (1<<8)) ) {   /* MPU Error (access violation) */
    mlc_printf("----> 0x%x\n",status);
    return 1;
  }
#endif

  status = readl( NANDC_REG_BUFFER_STATUS );
  if( ((status & 0xFFFF0000) != 0xFFFF0000) ) { /* Badblock marker set */
    return status;
  }

  return 0;
}

int nand_erase_block(uint32 block) {
  uint32 page,cfg0,cfg0_orig;

  page = block * chip_info.uPagesperblock;

  flash_wait_for_idle();

  cfg0_orig = cfg0 = readl(NAND_REG_DEV0_CFG0);
  
  cfg0  = (cfg0 & ~(0x7<<6)) & ~(0x7<<29);
  cfg0 |= 3<<27; /* Address cycles */
  cfg0 |= 0<< 6; /* 1 codeword only */
  writel(cfg0, NAND_REG_DEV0_CFG0);

  /* Addressing */
  writel( page, NAND_REG_ADDR0 ); /* [15:0] = Always 0, [31:16] = Low 16 bits of page# to read */
  writel(    0, NAND_REG_ADDR1 ); /* Upper 32 bits of page# to read */
  writel( 0x00000000, NAND_REG_FLASH_CHIP_SELECT );

#if VERBOSE_LOGGING
  mlc_printf("Executing command NAND_CMD_BLOCK_ERASE\n");
#endif
  writel( NAND_CMD_BLOCK_ERASE | (1<<4) | (1<<5), NAND_REG_FLASH_CMD );
  
  writel( 0x00000001, NANDC_REG_EXEC_CMD );
  flash_wait_for_idle();

  /* Restore CFG0 */
  writel(cfg0_orig, NAND_REG_DEV0_CFG0);

  return 0;
}

int nand_write_page(uint32 page, void *data) {
  uint32 *pData;
  int cw,i;

  flash_wait_for_idle();
  pData = data;

  /* Addressing */
  writel( (page&0xFFFF)<<16, NAND_REG_ADDR0 ); /* [15:0] = Always 0, [31:16] = Low 16 bits of page# to read */
  writel( page >> 16, NAND_REG_ADDR1 ); /* Upper 32 bits of page# to read */
  writel( 0x00000000, NAND_REG_FLASH_CHIP_SELECT );

#if VERBOSE_LOGGING
  mlc_printf("Executing command NAND_CMD_PAGE_PROGRAM_ECC\n");
#endif
  writel( NAND_CMD_PAGE_PROGRAM_ECC | (1<<4) | (1<<5), NAND_REG_FLASH_CMD );

  for(cw=0;cw<4;cw++) { /* Loop through all four codewords */
    /* Stuff the data into the buffer */
    for(i=0;i<(512/4);i++) {
      writel( pData[i], NAND_REG_FLASH_BUFFER + (i<<2));
    }
    pData += (512/4);

    writel( 0x00000001, NANDC_REG_EXEC_CMD );
    flash_wait_for_idle();
   }
  
  return 0;
}

int nand_read_page(uint32 page, void *data) {
  int i,cw;
  uint32 *pDest;
  //  if( !flash_ptrlist || !flash_cmdlist )
  //    return -1;

  pDest = data;

  flash_wait_for_idle();

  //  flash_dump_status();
  
  /* Addressing */
  writel( (page&0xFFFF)<<16, NAND_REG_ADDR0 ); /* [15:0] = Always 0, [31:16] = Low 16 bits of page# to read */
  writel( page >> 16, NAND_REG_ADDR1 ); /* Upper 32 bits of page# to read */
  writel( 0x00000000, NAND_REG_FLASH_CHIP_SELECT );

#if VERBOSE_LOGGING
  mlc_printf("Executing command NAND_CMD_PAGE_READ_ECC\n");
#endif
  writel( NAND_CMD_PAGE_READ | (1<<4) | (1<<5), NAND_REG_FLASH_CMD );

  for(cw=0;cw<4;cw++) { /* Loop through all four codewords */
    writel( 0x00000001, NANDC_REG_EXEC_CMD );
    flash_wait_for_idle();
    
    //    flash_dump_status();
    
    for(i=0;i<(512/4);i++) {
      pDest[i] = readl( NAND_REG_FLASH_BUFFER + (i<<2));
    }
    pDest += (512/4);
  }

  return 0;
}

uint32 nand_get_pagesPerBlock(void) {
  return chip_info.uPagesperblock;
}

uint32 nand_get_pagesSize(void) {
  return chip_info.uPagesize;
}

int nand_init(void) {
  uint32 uNandID;
  
  uNandID = flash_read_id();
  mlc_printf("[NAND] Found chip with ID 0x%x\n",uNandID);
  mlc_printf("[NAND] Page-size       : %u bytes\n",chip_info.uPagesize);
  mlc_printf("[NAND] Pages per block : %u\n",chip_info.uPagesperblock);
  mlc_printf("[NAND] Number of blocks: %u\n",chip_info.uTotalBlocks);
  mlc_printf("[NAND] Total size      : %u MB\n",(chip_info.uTotalBlocks * chip_info.uPagesperblock * chip_info.uPagesize) / 1024 / 1024);
  mlc_printf("[NAND] Width           : %s\n",chip_info.bIsWide ? "x16" : "x8");

  return 0;
}

int nand_config_pagesize(int size)
{
  uint32 cfg0;
  int rc = 0;
  
  cfg0 = readl(NAND_REG_DEV0_CFG0);

  /* Away with the unnecessary stuff */
  cfg0 &= 0xF87801FF;

  switch (size) {
    case 512:
      cfg0 |= (512 << 9);
      cfg0 |= (4 << 23);
      break;
    case 516:
      cfg0 |= (516 << 9);
      break;
    default:
      mlc_printf("nand_config_pagesize(): Unknown size 0x%x\n", size);
      rc = 1;
      break;
  }

  writel(cfg0, NAND_REG_DEV0_CFG0);

  return rc;
}