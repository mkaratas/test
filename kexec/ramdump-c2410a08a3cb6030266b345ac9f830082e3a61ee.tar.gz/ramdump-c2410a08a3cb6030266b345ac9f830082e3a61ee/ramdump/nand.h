#pragma once

int nand_init(void);

int nand_read_page(uint32 page, void *data);
int nand_is_block_bad(uint32 block);
int nand_erase_block(uint32 block);
int nand_write_page(uint32 page, void *data);

int nand_config_pagesize(int size);

uint32 nand_get_pagesPerBlock(void);
uint32 nand_get_pagesSize(void);