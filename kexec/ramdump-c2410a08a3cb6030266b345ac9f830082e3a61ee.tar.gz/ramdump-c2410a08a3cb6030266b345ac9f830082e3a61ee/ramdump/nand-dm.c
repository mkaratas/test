#include "io.h"
#include "nand.h"
#include "dmov.h"

#include "minilibc.h"

#define CMD_DST_CRCI(n)     (((n) & 15) << 7)
#define DMOV_NAND_CRCI_CMD    5
#define DST_CRCI_NAND_CMD  CMD_DST_CRCI(DMOV_NAND_CRCI_CMD)
#define DMOV_NAND_CRCI_DATA   4
#define SRC_CRCI_NAND_DATA CMD_SRC_CRCI(DMOV_NAND_CRCI_DATA)

#define CMD_PTR_ADDR(addr)  ((addr) >> 3)
#define CMD_PTR_LP          (1 << 31) /* last pointer */

#define CMD_SRC_CRCI(n)     (((n) & 15) << 3)

#define paddr(n) ((unsigned) (n))

struct flash_info flash_info;

typedef struct dmov_ch dmov_ch;
struct dmov_ch
{
  volatile unsigned cmd;
  volatile unsigned result;
  volatile unsigned status;
  volatile unsigned config;
};

static void dmov_prep_ch(dmov_ch *ch, unsigned id)
{
  ch->cmd = DMOV_CMD_PTR(id);
  ch->result = DMOV_RSLT(id);
  ch->status = DMOV_STATUS(id);
  ch->config = DMOV_CONFIG(id);
}

static unsigned int *flash_ptrlist;
static dmov_s *flash_cmdlist;

static unsigned CFG0, CFG1;
#define CFG1_WIDE_FLASH (1U << 1)
#define NAND_CFG0_RAW 0xA80420C0
#define NAND_CFG1_RAW 0x5045D

static unsigned int flash_pagesize = 0;



static int dmov_exec_cmdptr(unsigned id, unsigned *ptr)
{
  dmov_ch ch;
  unsigned n;

  dmov_prep_ch(&ch, id);

  writel(DMOV_CMD_PTR_LIST | DMOV_CMD_ADDR(paddr(ptr)), ch.cmd);
  mlc_printf("%s: Sent command\n",__func__);
  n = readl(ch.status);
  while(!(n & DMOV_STATUS_RSLT_VALID)) {
    mlc_printf("%s: status = 0x%x\n",__func__,n);
    n = readl(ch.status);
  }
  n = readl(ch.status);
  mlc_printf("%s: Got valid result\n",__func__);
  while(DMOV_STATUS_RSLT_COUNT(n)) {
    n = readl(ch.result);
    if(n != 0x80000002) {
      mlc_printf("ERROR: result: %x\n", n);
      mlc_printf("ERROR:  flush: %x %x %x %x\n",
	      readl(DMOV_FLUSH0(DMOV_NAND_CHAN)),
	      readl(DMOV_FLUSH1(DMOV_NAND_CHAN)),
	      readl(DMOV_FLUSH2(DMOV_NAND_CHAN)),
	      readl(DMOV_FLUSH3(DMOV_NAND_CHAN)));
    }
    n = readl(ch.status);
  }
  mlc_printf("%s: Exiting\n",__func__);
  return 0;
}

static uint32 flash_nand_read_id(dmov_s *cmdlist, unsigned *ptrlist)
{
  dmov_s *cmd = cmdlist;
  unsigned *ptr = ptrlist;
  unsigned *data = ptrlist + 4;

  mlc_printf(" - In flash_nand_read_id()\n");

  data[0] = 0 | 4;
  data[1] = NAND_CMD_FETCH_ID;
  data[2] = 1;
  data[3] = 0;
  data[4] = 0;
  data[5] = 0;
  data[6] = 0;
  data[7] = 0xAAD40000;  /* Default value for CFG0 for reading device id */

  mlc_printf(" - Building cmdlist\n");

  /* Read NAND device id */
  cmd[0].cmd = 0 | CMD_OCB;
  cmd[0].src = paddr(&data[7]);
  cmd[0].dst = NAND_DEV0_CFG0;
  cmd[0].len = 4;

  cmd[1].cmd = 0;
  cmd[1].src = NAND_SFLASHC_BURST_CFG;
  cmd[1].dst = paddr(&data[5]);
  cmd[1].len = 4;

  cmd[2].cmd = 0;
  cmd[2].src = paddr(&data[6]);
  cmd[2].dst = NAND_SFLASHC_BURST_CFG;
  cmd[2].len = 4;

  cmd[3].cmd = 0;
  cmd[3].src = paddr(&data[0]);
  cmd[3].dst = NAND_FLASH_CHIP_SELECT;
  cmd[3].len = 4;

  cmd[4].cmd = DST_CRCI_NAND_CMD;
  cmd[4].src = paddr(&data[1]);
  cmd[4].dst = NAND_FLASH_CMD;
  cmd[4].len = 4;

  cmd[5].cmd = 0;
  cmd[5].src = paddr(&data[2]);
  cmd[5].dst = NAND_EXEC_CMD;
  cmd[5].len = 4;

  cmd[6].cmd = SRC_CRCI_NAND_DATA;
  cmd[6].src = NAND_FLASH_STATUS;
  cmd[6].dst = paddr(&data[3]);
  cmd[6].len = 4;

  cmd[7].cmd = 0;
  cmd[7].src = NAND_READ_ID;
  cmd[7].dst = paddr(&data[4]);
  cmd[7].len = 4;

  cmd[8].cmd = CMD_OCU | CMD_LC;
  cmd[8].src = paddr(&data[5]);
  cmd[8].dst = NAND_SFLASHC_BURST_CFG;
  cmd[8].len = 4;

  ptr[0] = (paddr(cmd) >> 3) | CMD_PTR_LP;

  mlc_printf(" - About to execute cmdlist()\n");
  dmov_exec_cmdptr(DMOV_NAND_CHAN, ptr);

  mlc_printf("Flash ID: 0x%x\n",data[4]);

  return data[4];
}

#define NAND_CFG0_RAW 0xA80420C0
#define NAND_CFG1_RAW 0x5045D

static unsigned CFG0, CFG1;
static unsigned CFG0_M, CFG1_M;
static unsigned CFG0_A, CFG1_A;

#define CFG1_WIDE_FLASH (1U << 1)

unsigned nand_cfg0;
unsigned nand_cfg1;

static int flash_nand_read_config(dmov_s *cmdlist, unsigned *ptrlist)
{
	static unsigned CFG0_TMP, CFG1_TMP;

	mlc_printf("Hardcoding CFG0/CFG1\n");
	CFG0 = 0xaa5400c0;
	CFG1 = 0x000e745e;
	return 0;
#if 0
	cmdlist[0].cmd = CMD_OCB;
	cmdlist[0].src = NAND_DEV0_CFG0;
	cmdlist[0].dst = paddr(&CFG0_TMP);
	cmdlist[0].len = 4;

	cmdlist[1].cmd = CMD_OCU | CMD_LC;
	cmdlist[1].src = NAND_DEV0_CFG1;
	cmdlist[1].dst = paddr(&CFG1_TMP);
	cmdlist[1].len = 4;

	*ptrlist = (paddr(cmdlist) >> 3) | CMD_PTR_LP;

	dmov_exec_cmdptr(DMOV_NAND_CHAN, ptrlist);

	if((CFG0_TMP == 0) || (CFG1_TMP == 0)) {
		return -1;
	}

	CFG0_A = CFG0_TMP;
	CFG1_A = CFG1_TMP;
	if (flash_info.type == FLASH_16BIT_NAND_DEVICE) {
		nand_cfg1 |= CFG1_WIDE_FLASH;
	}
	mlc_printf("nandcfg: %x %x (initial)\n", CFG0, CFG1);

	CFG0_A = (((flash_pagesize >> 9) - 1) <<  6)  /* 4/8 cw/pg for 2/4k */
		|	(516 <<  9)  /* 516 user data bytes */
		|	(10 << 19)  /* 10 parity bytes */
		|	(5 << 27)  /* 5 address cycles */
		|	(0 << 30)  /* Do not read status before data */
		|	(1 << 31)  /* Send read cmd */
			/* 0 spare bytes for 16 bit nand or 1 spare bytes for 8 bit */
		|	((nand_cfg1 & CFG1_WIDE_FLASH) ? (0 << 23) : (1 << 23));
	CFG1_A = (0 <<  0)  /* Enable ecc */
		|	(7 <<  2)  /* 8 recovery cycles */
		|	(0 <<  5)  /* Allow CS deassertion */
	  	|	((flash_pagesize - (528 * ((flash_pagesize >> 9) - 1)) + 1) <<  6)	/* Bad block marker location */
		|	(0 << 16)  /* Bad block in user data area */
		|	(2 << 17)  /* 6 cycle tWB/tRB */
		|	(nand_cfg1 & CFG1_WIDE_FLASH); /* preserve wide flash flag */

	mlc_printf("nandcfg(Apps): %x %x (used)\n", CFG0_A, CFG1_A);

	CFG0_M = CFG0_TMP;
	CFG1_M = CFG1_TMP;
	if (flash_info.type == FLASH_16BIT_NAND_DEVICE) {
		nand_cfg1 |= CFG1_WIDE_FLASH;
	}
	CFG0_M = (((flash_pagesize >> 9) - 1) <<  6)  /* 4/8 cw/pg for 2/4k */
		|	(512 <<  9) /* 512 user data bytes */
		|	(10 << 19)  /* 10 parity bytes */
		|	(5 << 27)  /* 5 address cycles */
		|	(0 << 30)  /* Do not read status before data */
		|	(1 << 31)  /* Send read cmd */
		|	((nand_cfg1 & CFG1_WIDE_FLASH) ? (4 << 23) : (5 << 23));
	CFG1_M = (0 <<  0)  /* Enable ecc */
		|	(7 <<  2)  /* 8 recovery cycles */
		|	(0 <<  5)  /* Allow CS deassertion */
		|	((flash_pagesize - (528 * ((flash_pagesize >> 9) - 1)) + 1) <<  6)	/* Bad block marker location */
		|	(0 << 16)  /* Bad block in user data area */
		|	(2 << 17)  /* 6 cycle tWB/tRB */
		|	(nand_cfg1 & CFG1_WIDE_FLASH); /* preserve wide flash flag */
	mlc_printf("nandcfg(Modem): %x %x (used)\n", CFG0_M, CFG1_M);

	CFG0 = CFG0_M;
	CFG1 = CFG1_M;

	return 0;
#endif
}


static int flash_nand_block_isbad(dmov_s *cmdlist, unsigned *ptrlist,
				  unsigned page)
{
  dmov_s *cmd = cmdlist;
  unsigned *ptr = ptrlist;
  unsigned *data = ptrlist + 4;
  char buf[4];
  unsigned cwperpage;

  cwperpage = (flash_pagesize >> 9);

  /* Check first page of this block */
  if(page & 63)
    page = page - (page & 63);

  /* Check bad block marker */
  data[0] = NAND_CMD_PAGE_READ;   /* command */

  /* addr0 */
  if (CFG1 & CFG1_WIDE_FLASH)
    data[1] = (page << 16) | ((528*(cwperpage-1)) >> 1);
  else
    data[1] = (page << 16) | (528*(cwperpage-1));

  data[2] = (page >> 16) & 0xff;                                          /* addr1        */
  data[3] = 0 | 4;                                                                        /* chipsel
											   */
  data[4] = NAND_CFG0_RAW & ~(7U << 6);                           /* cfg0         */
  data[5] = NAND_CFG1_RAW | (CFG1 & CFG1_WIDE_FLASH);     /* cfg1         */
  data[6] = 1;
  data[7] = CLEAN_DATA_32;        /* flash status */
  data[8] = CLEAN_DATA_32;        /* buf status   */

  cmd[0].cmd = DST_CRCI_NAND_CMD | CMD_OCB;
  cmd[0].src = paddr(&data[0]);
  cmd[0].dst = NAND_FLASH_CMD;
  cmd[0].len = 16;

  cmd[1].cmd = 0;
  cmd[1].src = paddr(&data[4]);
  cmd[1].dst = NAND_DEV0_CFG0;
  cmd[1].len = 8;

  cmd[2].cmd = 0;
  cmd[2].src = paddr(&data[6]);
  cmd[2].dst = NAND_EXEC_CMD;
  cmd[2].len = 4;

  cmd[3].cmd = SRC_CRCI_NAND_DATA;
  cmd[3].src = NAND_FLASH_STATUS;
  cmd[3].dst = paddr(&data[7]);
  cmd[3].len = 8;

  cmd[4].cmd = CMD_OCU | CMD_LC;
  cmd[4].src = NAND_FLASH_BUFFER + (flash_pagesize - (528*(cwperpage-1)));
  cmd[4].dst = paddr(&buf);
  cmd[4].len = 4;

  ptr[0] = (paddr(cmd) >> 3) | CMD_PTR_LP;

  mlc_printf("%s: Pre DM Exec\n",__func__);
  dmov_exec_cmdptr(DMOV_NAND_CHAN, ptr);
  mlc_printf("%s: Post DM Exec\n",__func__);

  /* we fail if there was an operation error, a mpu error, or the
  ** erase success bit was not set.
  */
  if(data[7] & 0x110) {
    mlc_printf("%s: Op-error, mpu-error, erasebit not set?\n",__func__);
    return -1;
  }

  /* Check for bad block marker byte */
  mlc_printf("%s: CFG1=0x%x CFG1_WIDE_FLASH=0x%x\n",__func__,CFG1,CFG1_WIDE_FLASH);
  if (CFG1 & CFG1_WIDE_FLASH) {
    if (buf[0] != 0xFF || buf[1] != 0xFF)
      return 1;
  } else {
    if (buf[0] != 0xFF)
      return 1;
  }

  return 0;
}

struct data_flash_io {
  unsigned cmd;
  unsigned addr0;
  unsigned addr1;
  unsigned chipsel;
  unsigned cfg0;
  unsigned cfg1;
  unsigned exec;
  unsigned ecc_cfg;
  unsigned ecc_cfg_save;
  unsigned clrfstatus;
  unsigned clrrstatus;
  struct {
    unsigned flash_status;
    unsigned buffer_status;
  } result[8];
};



static int _flash_nand_read_page(dmov_s *cmdlist, unsigned *ptrlist,
				 unsigned page, void *_addr, void *_spareaddr)
{
  dmov_s *cmd = cmdlist;
  unsigned *ptr = ptrlist;
  struct data_flash_io *data = (void*) (ptrlist + 4);
  unsigned addr = (unsigned) _addr;
  unsigned spareaddr = (unsigned) _spareaddr;
  unsigned n;
  int isbad = 0;
  unsigned cwperpage;

  mlc_printf("%s: Entered.. (flash_pagesize=%u)\n",__func__,flash_pagesize);

  cwperpage = (flash_pagesize >> 9);

  /* Check for bad block and read only from a good block */
  isbad = flash_nand_block_isbad(cmdlist, ptrlist, page);
  if (isbad) {
    mlc_printf("In _flash_nand_read_page.. flash_nand_block_isbad != 0 (was: %i)\n",isbad);
    return -2;
  }

  data->cmd = NAND_CMD_PAGE_READ_ECC;
  data->addr0 = page << 16;
  data->addr1 = (page >> 16) & 0xff;
  data->chipsel = 0 | 4; /* flash0 + undoc bit */

  /* GO bit for the EXEC register */
  data->exec = 1;

  data->cfg0 = CFG0;
  data->cfg1 = CFG1;

  data->ecc_cfg = 0x203;

  /* save existing ecc config */
  cmd->cmd = CMD_OCB;
  cmd->src = NAND_EBI2_ECC_BUF_CFG;
  cmd->dst = paddr(&data->ecc_cfg_save);
  cmd->len = 4;
  cmd++;

#if 0
  mlc_printf("%s: cwperpage=%i\n",__func__,cwperpage);
  for(n = 0; n < cwperpage; n++) {
    /* write CMD / ADDR0 / ADDR1 / CHIPSEL regs in a burst */
    cmd->cmd = DST_CRCI_NAND_CMD;
    cmd->src = paddr(&data->cmd);
    cmd->dst = NAND_FLASH_CMD;
    cmd->len = ((n == 0) ? 16 : 4);
    cmd++;

    if (n == 0) {
      /* block on cmd ready, set configuration */
      cmd->cmd = 0;
      cmd->src = paddr(&data->cfg0);
      cmd->dst = NAND_DEV0_CFG0;
      cmd->len = 8;
      cmd++;

      /* set our ecc config */
      cmd->cmd = 0;
      cmd->src = paddr(&data->ecc_cfg);
      cmd->dst = NAND_EBI2_ECC_BUF_CFG;
      cmd->len = 4;
      cmd++;
    }
    /* kick the execute register */
    cmd->cmd = 0;
    cmd->src = paddr(&data->exec);
    cmd->dst = NAND_EXEC_CMD;
    cmd->len = 4;
    cmd++;

    /* block on data ready, then read the status register */
    cmd->cmd = SRC_CRCI_NAND_DATA;
    cmd->src = NAND_FLASH_STATUS;
    cmd->dst = paddr(&data->result[n]);
    cmd->len = 8;
    cmd++;

    /* read data block */
    cmd->cmd = 0;
    cmd->src = NAND_FLASH_BUFFER;
    cmd->dst = addr + n * 512;
    cmd->len = ((n < (cwperpage -1 )) ? (512+16) : (512 - ((cwperpage - 1) << 2)));
    cmd++;
  }

  /* read extra data */
  cmd->cmd = 0;
  cmd->src = NAND_FLASH_BUFFER + 512;
  cmd->dst = spareaddr;
  cmd->len = 16;
  cmd++;

  /* restore saved ecc config */
  cmd->cmd = CMD_OCU | CMD_LC;
  cmd->src = paddr(&data->ecc_cfg_save);
  cmd->dst = NAND_EBI2_ECC_BUF_CFG;
  cmd->len = 4;
#endif
  ptr[0] = (paddr(cmdlist) >> 3) | CMD_PTR_LP;

  mlc_printf("%s: Pre DM Exec\n",__func__);
  dmov_exec_cmdptr(DMOV_NAND_CHAN, ptr);
  mlc_printf("%s: Post DM Exec\n",__func__);

#if VERBOSE
  dprintf(INFO, "read page %d: status: %x %x %x %x\n",
	  page, data[5], data[6], data[7], data[8]);
  for(n = 0; n < 4; n++) {
    ptr = (unsigned*)(addr + 512 * n);
    dprintf(INFO, "data%d:  %x %x %x %x\n", n, ptr[0], ptr[1], ptr[2], ptr[3]);
    ptr = (unsigned*)(spareaddr + 16 * n);
    dprintf(INFO, "spare data%d     %x %x %x %x\n", n, ptr[0], ptr[1], ptr[2], ptr[3]);
  }
#endif

  /* if any of the writes failed (0x10), or there was a
  ** protection violation (0x100), we lose
  */
  for(n = 0; n < cwperpage; n++) {
    if (data->result[n].flash_status & 0x110) {
      mlc_printf("Wtf-error..\n");
      return -1;
    }
  }

  return 0;
}

/* Wrapper functions */
static void flash_read_id(dmov_s *cmdlist, unsigned *ptrlist)
{
  int dev_found = 0;
  unsigned index;
  uint32 uNandID;

  // Try to read id
  uNandID = flash_nand_read_id(cmdlist, ptrlist);

  /* TODO: Add more stuff here... */
  if( uNandID == 0x55d1b32c ) { /* Micron 8Gb x16 */
    flash_info.id = uNandID;
    flash_info.type = FLASH_16BIT_NAND_DEVICE;
    flash_info.vendor = uNandID & 0xFF;
    flash_info.device = (uNandID>>8) & 0xFF;
    flash_info.page_size  = 2048;
    flash_info.block_size = 2048 * 64;
    flash_info.spare_size = 64;
    flash_info.num_blocks = 8192;

    flash_pagesize = flash_info.page_size;
  }
}

int flash_read_page(uint32 page, void *data, void *extra) {
  if( !flash_ptrlist || !flash_cmdlist )
    return -1;

  return _flash_nand_read_page(flash_cmdlist, flash_ptrlist,
			       page,data,extra);
}

int nand_init(void) {

  flash_ptrlist = (unsigned int*)mlc_malloc(2048);
  flash_cmdlist = (dmov_s*)mlc_malloc(2048);

  mlc_printf("Calling flash_nand_read_id()\n");
  flash_read_id( flash_cmdlist, flash_ptrlist );

  if(flash_nand_read_config(flash_cmdlist, flash_ptrlist)) {
    mlc_printf("ERROR: could not read CFG0/CFG1 state\n");
    return -1;
  }

  return 0;
}
