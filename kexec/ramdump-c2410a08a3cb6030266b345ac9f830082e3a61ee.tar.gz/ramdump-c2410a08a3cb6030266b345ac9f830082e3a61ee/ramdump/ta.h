/*********************************************************************
 *  ____                      _____      _                           *
 * / ___|  ___  _ __  _   _  | ____|_ __(_) ___ ___ ___  ___  _ __   *
 * \___ \ / _ \| '_ \| | | | |  _| | '__| |/ __/ __/ __|/ _ \| '_ \  *
 *  ___) | (_) | | | | |_| | | |___| |  | | (__\__ \__ \ (_) | | | | *
 * |____/ \___/|_| |_|\__, | |_____|_|  |_|\___|___/___/\___/|_| |_| *
 *                    |___/                                          *
 *                                                                   *
 *********************************************************************
 * Copyright 2006-2009 Sony Ericsson Mobile Communications AB.       *
 * All rights, including trade secret rights, reserved.              *
 *********************************************************************/

/***  IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT  ***
 *                                                                   *
 * All changes to the Trim Area implementation must be cleared with  *
 * Flash Core Security (the loader developers) in order to ensure    *
 * that the loaders stay functional after a change.                  *
 *                                                                   *
 * Failure to do so may incur severe costs for the company due to    *
 * halted or faulty production.                                      *
 *                                                                   *
 * Signed: Hans Wachtmeister (Loader MA) 2009-03-30                  *
 *                                                                   *
 ***  IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT  ***/

/**
 * @file ta.h
 *
 * @brief Trim Area (TA). 
 *
 * The implementation of the Trim Area is meant to provide functionality for 
 * storing small data units in persistent memory. To make the implementation 
 * independant of the type of storage used, the client have to provide a set 
 * of functions that can be used by the TA when it need to read or manipulate 
 * the storage media (see ta_types.h for a more detailed description).
 *
 * See TA_Open() for a brief description on the flash resources the TA require
 * to function properly.
 *
 * Note that the implementation is not thread safe, so no more than one 
 * process should at any time use the TA. If there is a need for several 
 * processes to access the TA, the client have to implement an abstraction 
 * layer that takes care of this.
 *
 * Version description:
 * v1: This version will allocate an erase sized block of memory to store
 *     data in, regardless of the actual amount of data. It will also 
 *     write the complete (erase sized) block to flash, regardless of how
 *     much valid data it actually contains.
 *
 * v2: Version 2 is fully compatible with version 1, and can read/write data in
 *     the old version 1 format. To be able to handle both formats, the 
 *     TA_Format call now takes the desired version as an input parameter.
 *
 *
 *     - Memory Usage -
 *     This version allocates data storage in 2KB chunks, instead of allocating
 *     a whole erase sized block. This reduces the memory usage significantly, 
 *     but it also means that where version 1 had its peak consumption of RAM
 *     when it was opened, version 2 may have its peak during a write. When a 
 *     new block of RAM have to be allocated, during a call to WriteData to fit 
 *     new data, it will require 'old data size' rounded up to the neareast 2KB 
 *     boundry, plus 'new data size' rounded up to the nearest 2KB boundry).
 *
 *     ex: Old data size = 5KB -> Requires 6KB RAM allocation.
 *         When a 1.5KB unit (including headers) is written, the TA will 
 *         require 6KB + 8KB (5KB+1.5KB rounded up = 8KB) of RAM.
 *
 *     Note that additional memory will also be allocated for other 
 *     functionality, and that the use 'data size' also includes headers 
 *     needed internally by the TA.
 *
 *
 *     - New or Changed Interfaces -
 *     TA_Format() has been replaced with a new TA_Format, that require the
 *       caller to specify the desired version (see interface description 
 *       below).
 *     TA_Open() is now obsolete.
 *     TA_SetConfig()          (see interface description below).
 *     TA_OpenPartition()      (see interface description below).
 *     TA_GetVersion()         (see interface description below).
 *     TA_IsVersionSupported() (see interface description below).
 *
 *
 * @ingroup TA
 *
 * @copyright 2006-2009, Sony Ericsson Mobile Communications AB
 *
 * @responsible Jens-Henrik Lindskov (jens-henrik.lindskov@sonyericsson.com)
 *
 * @todo 
 *
 * @review
 */
#ifndef INCLUSION_GUARD_TA
#define INCLUSION_GUARD_TA


//////////////////////////////////////////////////////////////////////
/// @name Includes
//@{
#include "ta_types.h"
//@} End of Includes


//////////////////////////////////////////////////////////////////////
/// @name Defines
//@{
//@} End of Defines


//////////////////////////////////////////////////////////////////////
/// @name Public Methods
//@{
/**
 * Configurates/Initiates the TA, and must have been called prior to calling
 * any other TA interface. 
 *
 * The start address tells the TA where its first (erase sized) block of 
 * persistent memory is located. The TA will require atleast one (1) block per
 * used partition, as well as one (1) extra back up block to be able to 
 * recover from a crash. Thus, to support 2 partitions, the TA will need at 
 * least 3 functional blocks. The blocks should address wise be consecutive, 
 * since the calls to the external (client implemented) functions will be made 
 * with that assumption.
 *
 * example: 
 *   TA_SetConfig(&funcs, 
 *                0x20000000,
 *                0x40000, 
 *                5);
 *
 * @param[in] pFuncs A pointer to a struct that should contain function 
 *                   pointers to all the functions needed to be implemented 
 *                   by the client. See ta_types.h.
 * @param[in] startAddr The first address of the flash section allocated for
 *                      the TA. Have to be (erase) block aligned.
 * @param[in] eBlkSize  Size of an erase block      
 * @param[in] nbrOfBlks Number of erase blocks allocated for the TA.
 *
 * @returns TA_ErrCode_t
 */
TA_ErrCode_t TA_SetConfig(const TA_Functions_t* pFuncs,
                          uint32 startAddr, 
                          uint32 eBlkSize,
                          uint8  nbrOfBlks);


/**
 * This function opens a partition so data can be read/written to/from it, or
 * to allow formatting. Different partitions can not be open simultaneously, so 
 * prior to opening a partion, all partions must be closed.
 *
 * example:
 *   TA_OpenPartition(TA_TRIM_PART, 
 *                    TA_READ | TA_SAFE_WRITE);
 *
 * If the TA will handle more than one partition, it should be noted that the
 * TA only recognize partitions with versions supported by the current 
 * implementation, so if ANY partition contain an unsupported version, data 
 * loss may occur.
 *
 * Note: The function will return TA_Invalid if the requested partition wasn't
 *       found, or if the partition contained a version not supported by the
 *       current implementation. and a call to TA_Format is required to proceed. 
 *       In this particular case (TA_Invalid), the TA is still considered to be 
 *       open, even if an error was returned, to allow a call to TA_Format.
 *
 * @param[in] partition The partition you want access to. 
 * @param[in] mode   Combine (OR) the read/write options. TA_RAM_WRITE and
 *                   TA_SAFE_WRITE can not be used at the same time.
 *
 *                   TA_READ: Allows reading of units.
 *                   TA_RAM_WRITE: See ta_types.h.
 *                   TA_SAFE_WRITE: See ta_types.h
 *                   
 * @returns TA_ErrCode_t
 */
TA_ErrCode_t TA_OpenPartition(uint8 partition,
                              uint8 mode);


/**
 * Closes the TA. This function should be the last TA call made from
 * the client, as it shuts down the TA and deallocate all resources
 * that has been used by the TA.
 * 
 * Note that TA_Close won't flush (write) the data to flash.
 *
 * @returns TA_ErrCode_t
 */
TA_ErrCode_t TA_Close(void);


/**
 * This function will return the TA version used in the specified partition, and
 * can be called before TA_OpenPartition to find out what version a specific 
 * partition is using. Together with TA_IsVersionSupported, this makes it 
 * possible for the user to see if the current TA implementation can read and
 * write data to/from that partition.
 *
 * This interface require that TA_SetConfig has been called successfully.
 *
 * @param[out] pVersion  Will contain the used version, or 0 if no valid version
 *                       has been found.
 * @param[in]  partition The partition the caller wants version info from.
 *
 * @returns TA_ErrCode_t
 */
TA_ErrCode_t TA_GetVersion(uint8* pVersion, uint8 partition);


/**
 * This function will return TRUE if the supplied version is supported by the
 * used TA implementation, and FALSE otherwise. It can be called before the
 * TA is actually opened to verify that the current implementation can handle
 * the data.
 *
 * @param[in] version The version you want to test the support for.
 *
 * @returns boolean TRUE if supported, and FALSE otherwise.
 */
boolean TA_IsVersionSupported(uint8 version);


/**
 * Formats the TA. This function would typically be used if it's the first 
 * time the TA is opened, and the TA_Invalid code is returned from that call.
 * Only the partition that was requested when the TA was opened will be 
 * affected.
 *
 * Note that it is possible to have different data formats (versions) in 
 * different partitions, but it's recommended to use the same format/version
 * in all partitions (see TA_OpenPartition()).
 *
 * @param[in] version The version that the open partition should conform to.
 *
 * @returns TA_ErrCode_t
 */
TA_ErrCode_t TA_Format(uint8 version);


/**
 * This function writes down the current TA units to flash. Normally, a call 
 * to TA_Flush is done at the end of a session, before the TA is closed. This 
 * function is only applicable if the TA was opened with the TA_RAM_WRITE 
 * option.
 *
 * @returns TA_ErrCode_t
 */
TA_ErrCode_t TA_Flush(void);


/**
 * This function will add, or overwrite, a TA unit. If a new unit size is
 * provided for an already existing unit, the unit will grow or shrink 
 * accordingly.
 *
 * @param[in]  unit  The unit number of the unit to be written.
 * @param[in]  pData A pointer to the data to be written to the unit.
 * @param[in]  size  The size of the data.
 *
 * @returns TA_ErrCode_t
 */
TA_ErrCode_t TA_WriteData(uint32 unit, const uint8* pData, uint32 size);


/**
 * This function will read a TA unit from the TA block, and return the
 * associated data.
 *
 * @param[in]  unit  The unit number of the unit to be read.
 * @param[out] pData A pointer to where the unit data should be written.
 *                   This buffer should be atleast as big as the units
 *                   data size.
 * @param[in]  size  The size of the data.
 *
 * @returns TA_ErrCode_t
 */
TA_ErrCode_t TA_ReadData(uint32 unit, uint8* pData, uint32 size);


/**
 * This function will return the size of the data associated with the provided
 * unit.
 *
 * @param[in]  unit  The unit number of the unit to be read.
 *
 * @returns uint32   0 if no unit was found, otherwise the size of the unit.
 */
uint32 TA_GetUnitSize(uint32 unit);


/**
 * This function will delete a TA unit from the partition that is currently 
 * open.
 *
 * @param[in]  unit  The unit number of the unit to be deleted.
 *
 * @returns TA_ErrCode_t
 */
TA_ErrCode_t TA_DeleteUnit(uint32 unit);


/**
 * TA_Open is a version 1 legacy interface that shouldn't be used. Its ONLY 
 * purpose is to make integration into environments that use v1 easier.
 *
 * Basically, this function is mapped into two other calls, namely:
 * TA_SetConfig() + TA_OpenPartition()
 * 
 * @param[in] pFuncs A pointer to a struct that should contain function 
 *                   pointers to all the functions needed to be implemented 
 *                   by the client. See ta_types.h.
 * @param[in] mode   Combine (OR) the read/write options. TA_RAM_WRITE and
 *                   TA_SAFE_WRITE can not be used at the same time.
 *
 *                   TA_READ: Allows reading of units.
 *                   TA_RAM_WRITE: See ta_types.h.
 *                   TA_SAFE_WRITE: See ta_types.h
 *                   
 * @param[in] partition The partition you want access to. 
 * @param[in] addr      The first address of the flash section allocated for
 *                      the TA. Have to be (erase) block aligned.
 * @param[in] eBlkSize  Size of an erase block      
 * @param[in] nbrOfBlks Number of erase blocks allocated for the TA.
 *
 * @returns TA_ErrCode_t
 */
TA_ErrCode_t TA_Open(const TA_Functions_t* pFuncs,
                     uint8  mode, 
                     uint8  partition,
                     uint32 addr, 
                     uint32 eBlkSize,
                     uint8  nbrOfBlks);


/*
 * Functions needed to incrementally read out the units from the TA. These 
 * functions are NOT accessible if the TA has been opened with either of the
 * TA_RAM_WRITE or TA_SAFE_WRITE options. 
 *
 * These functions only exist as a mean to read out all the units for debugging
 * purposes, or to copy them to another unit handling implementation. If the 
 * intention is to keep the data in the TA at all time, these functions should 
 * probably be ignored.
 *
 * Note that the first unit is already pointed out when the TA is opened, so
 * the need to advance in the list is only necessary when the 2nd unit is needed
 * and so forth.
 *
 * Crude example:
 * while(TA_Inc_GetSize(&size) == TA_Success)
 * {
 *   pData = malloc(size);
 *   TA_Inc_Read(&unit, pData, size);
 *   - Handle the unit/data -
 *   free(pData);
 *   TA_Inc_NextUnit();
 * }
 */

/**
 * This function will read out the size of the unit currently pointed out by
 * the internal incremental read structure.
 *
 * @param[out]  pSize  The size of the current unit.
 *
 * @returns TA_ErrCode_t
 */
TA_ErrCode_t TA_Inc_GetSize(uint32* pSize);


/**
 * This function will read out the unit number and the corresponding data of 
 * the unit currently pointed out by the internal incremental read structure.
 *
 * @param[out]  pUnit  The unit number. 
 * @param[out]  pData  A pointer to the unit's data
 * @param[in]   size   The unit's size (obtained by TA_Inc_GetSize()).
 *
 * @returns TA_ErrCode_t
 */
TA_ErrCode_t TA_Inc_Read(uint32* pUnit, uint8* pData, uint32 size);


/**
 * This function will point out the next valid unit in the TA structure. Note
 * the the first unit is pointed out by default, so it's only necessary to 
 * call this function when there's a need to incrementally point out the 
 * units after the first one.
 *
 * If this function is called after reaching the end of the list of units, 
 * i.e the error code TA_UnitNotFound has been received, the internal structure
 * will be reset and the list can once again be traversed.
 *
 * @returns TA_ErrCode_t
 */
TA_ErrCode_t TA_Inc_NextUnit(void);

#ifdef CFG_TA_DEBUG
/**
 * This function is used for debug to inspect the available TA blocks.
 * Status is returned for every available block. TA_SetConfig must have
 * been called before this function is called.
 * This function does not affect any blocks or the state in the library.
 *
 * @param[out]  status     Status will be set here. See TA_Dbg_BlkStatus_t.
 * @param[out]  partition  Partition number or additional info will be set here.
 * @param[out]  version    Version or additional info will be set here.
 */
void TA_Dbg_InspectBlocks(uint32 *status, uint32 *partition, uint32 *version);
#endif

//@} End of Public Methods
#endif

