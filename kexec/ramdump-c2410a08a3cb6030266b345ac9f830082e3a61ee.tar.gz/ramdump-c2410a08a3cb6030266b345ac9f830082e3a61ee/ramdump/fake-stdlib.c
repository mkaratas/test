
#include "fake-stdlib.h"

void *malloc(size_t size) {
  return mlc_malloc(size);
}

void  free(void *ptr) {
  
}

void *memset(void *s, int c, size_t n) {
  return mlc_memset(s,c,n);
}

#if 0
void *memcpy(void *dest, const void *src, size_t n) {
  return mlc_memcpy(dest,src,n);
}

#endif
