#pragma once

#include "nand_int.h"


int nand_init(void);
int flash_read_page(uint32 page, void *data, void *extra);
