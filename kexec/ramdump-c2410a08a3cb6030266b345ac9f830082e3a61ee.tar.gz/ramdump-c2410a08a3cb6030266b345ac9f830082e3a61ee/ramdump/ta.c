/*********************************************************************
 *  ____                      _____      _                           *
 * / ___|  ___  _ __  _   _  | ____|_ __(_) ___ ___ ___  ___  _ __   *
 * \___ \ / _ \| '_ \| | | | |  _| | '__| |/ __/ __/ __|/ _ \| '_ \  *
 *  ___) | (_) | | | | |_| | | |___| |  | | (__\__ \__ \ (_) | | | | *
 * |____/ \___/|_| |_|\__, | |_____|_|  |_|\___|___/___/\___/|_| |_| *
 *                    |___/                                          *
 *                                                                   *
 *********************************************************************
 * Copyright 2006-2009 Sony Ericsson Mobile Communications AB.       *
 * All rights, including trade secret rights, reserved.              *
 *********************************************************************/

/***  IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT  ***
 *                                                                   *
 * All changes to the Trim Area implementation must be cleared with  *
 * Flash Core Security (the loader developers) in order to ensure    *
 * that the loaders stay functional after a change.                  *
 *                                                                   *
 * Failure to do so may incur severe costs for the company due to    *
 * halted or faulty production.                                      *
 *                                                                   *
 * Signed: Hans Wachtmeister (Loader MA) 2009-03-30                  *
 *                                                                   *
 ***  IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT  ***/

/**
 * @file ta.c
 *
 * @brief Trim Area (TA).
 *
 * @ingroup TA
 *
 * @copyright 2006-2009, Sony Ericsson Mobile Communications AB
 *
 * @responsible Jens-Henrik Lindskov (jens-henrik.lindskov@sonyericsson.com)
 *
 * @review
 */

//============================================================================
//= Includes
//============================================================================
#include "ta.h"
#include "ta_types.h"
#include "minilibc.h"

//============================================================================
//= Macros & Defines
//============================================================================
//The current TA version.
//Version 1: Whole (erase sized) blocks was always used to store the units in 
//           RAM, and the whole block was also written to flash regardless of 
//           the actual amount of data in it.
//Version 2: Added a 'used' variable in the block information. Due to the fact
//           that we want to be backward compatible, and that only 1 byte was
//           unused in the block header, it wasn't possible to just write down
//           the exact amount of used data in the block. Instead it has a 
//           granularity of 2KB (see TA_Blk_t->used).  
#define TA_VERSION 2 

//Every valid block has this magic number. It's a fast way to decide if a 
//block is valid, so we can skip the checksum calculations for blocks that's
//clearly not OK.
#define TA_MAGIC  0x3BF8E9C1 

//Defines to make the accessing of externally implemented functions easier.
#define TA_ReadBlock(addr, pData, size) \
        taFunc.ReadBlock(addr, pData, size)
#define TA_WriteBlock(addr, pData, size) taFunc.WriteBlock(addr, pData, size)
#define TA_EraseBlock(addr)              taFunc.EraseBlock(addr)
#define TA_IsBadBlock(addr)              taFunc.IsBadBlock(addr)
#define TA_Malloc(size)                  taFunc.Malloc(size)
#define TA_Free(addr) do\
                      {\
                        if((addr) != NULL)\
                        {\
                          taFunc.Free((addr));\
                          (addr) = NULL;\
                        }\
                      }while(0)

//Return the size of a complete unit (header + data).
#define UnitSize(pUnit) (sizeof(TA_Unit_t) + RealDataSize(pUnit->size)) 

//TA Granularity - See TA_Blk_t->used
#define TAG (2*1024)


//============================================================================
//= Internal type definitions
//============================================================================
//Flash block structure
typedef struct
{
  uint32 magic;    //TA_MAGIC
  uint32 chkSum;   //Adler32 that cover: block - magic - chkSum
  uint8  version;  //Numerical version number
  uint8  blkNbr;   //Block number
  uint8  partition;//The partition the block belong to. 
  uint8  used;     //How much data in the block that is used ((used+1)*TAG).
                   //0xFF = whole block (regardless of its actual size).
  uint8  data[];   //Will point to the first unit in the block.
} TA_Blk_t;

//Unit
typedef struct
{
  uint32 unit;
  uint32 size;
  uint32 magic; //TA_MAGIC
  uint32 reserved;
  uint8  data[];//Note that this is only the reference point to the first byte
                //of data. There will be 'size' bytes of data here. The reason
                //we don't use a pointer here is to keep the memory structure
                //consistant with what we will store in flash.
} TA_Unit_t;

//Double Linked List Element
typedef struct TA_Element
{
  struct TA_Element* pPrev;
  struct TA_Element* pNext;
  uint32             addr; //The flash address
  TA_Blk_t*          pBlk;
} TA_Element_t;

//Struct to keep track of states etc.
typedef struct
{
  uint8         mode;      //Which mode was requested when the TA was opened.
  uint8         partition; //The current partition.
  boolean       isValid;   //When opened, was there a valid TA present?
  uint8         version;   //TA version in current partion.
  uint32        startAddr; //Address to the first block allocated for the TA.
  uint32        eBlkSize;  //Size of an erase block.
  uint8         usedBlks;  //Current number of used blocks
  uint8         nbrOfBlks; //Number of erase blocks allocated for the TA.
  uint32        scrAddr;   //Address to the scratch block.
  TA_Unit_t*    pIncUnit;  //Current Unit for the Incremental functions.
  TA_Element_t* pIncElem;  //Current Element for the Incremental functions. 
}TA_t;


//============================================================================
//= Private Function Prototypes
//============================================================================
static TA_Element_t* ListAllocElem(void);
static TA_Element_t* ListCreate(void);
static void ListDestroy(TA_Element_t *pList);
static void ListAddLast(TA_Element_t* pList, TA_Element_t* pElem);
static TA_Element_t* ListUnlink(TA_Element_t* pList, TA_Element_t* pElem);
static TA_Element_t* ListGetFirst(TA_Element_t* pList);
static TA_Element_t* ListGetNext(TA_Element_t* pList, TA_Element_t* pElem);

static TA_Unit_t* FindUnit(uint32 unit,
                           TA_Element_t* pStartElem,
                           TA_Unit_t* pStartUnit,
                           TA_Element_t** ppFoundInElem);
static TA_Blk_t* BlkAlloc(uint8 version);
static TA_ErrCode_t BlkWrite(TA_Element_t* pElem);
static TA_Unit_t* BlkFindUnit(TA_Blk_t* pBlk, 
                              TA_Unit_t* pStartUnit, 
                              uint32 unit);
static TA_ErrCode_t BlkWriteUnit(TA_Element_t* pElem,
                                 uint32 unit, 
                                 const uint8* pData, 
                                 int size);
static TA_Unit_t* BlkGetFirstUnit(TA_Blk_t* pBlk);
static TA_Unit_t* BlkGetNextUnit(TA_Blk_t* pBlk, TA_Unit_t* pUnit); 
static TA_ErrCode_t BlkEraseUnit(TA_Blk_t* pBlk, TA_Unit_t* pUnit);
static int RealDataSize(uint32 inSize);

static uint32 TA_CheckSum(TA_Blk_t* pBlk);
static void CrashRecovery(void);

static uint32 BlkGetUsedSize(TA_Blk_t* pBlk);
static void BlkSetUsedSize(TA_Blk_t* pBlk, uint32 size);


//============================================================================
//= Global variables
//============================================================================
static TA_Functions_t taFunc;
static TA_t ta = {0, 0, FALSE, 0, 0, 0, 0, 0, 0, NULL, NULL};
static TA_Element_t* pUsedList;
static TA_Element_t* pFreeList;


//============================================================================
//= Public Functions
//============================================================================
//TA_Open is a version 1 legacy interface...
TA_ErrCode_t TA_Open(const TA_Functions_t* pFuncs,
                     uint8  mode,
                     uint8  partition,
                     uint32 addr, 
                     uint32 eBlkSize,
                     uint8  nbrOfBlks)
{
  TA_ErrCode_t r;

  r = TA_SetConfig(pFuncs, addr, eBlkSize, nbrOfBlks);

  if(TA_Success == r)
  {
    r = TA_OpenPartition(partition, mode);
  }

  return r;
}


TA_ErrCode_t TA_SetConfig(const TA_Functions_t* pFuncs,
                          uint32 startAddr, 
                          uint32 eBlkSize,
                          uint8  nbrOfBlks)
{
  if(ta.mode != 0)
  {
    //Shouldn't try to reconfigure an already open TA.
    return TA_Configuration;
  }

  if(pFuncs == NULL)
  {
    return TA_Parameters;
  }

  mlc_memcpy(&taFunc, pFuncs, sizeof(TA_Functions_t));

  ta.startAddr = startAddr;
  ta.eBlkSize  = eBlkSize;
  ta.nbrOfBlks = nbrOfBlks;

  return TA_Success;
}


TA_ErrCode_t TA_OpenPartition(uint8 partition,
                              uint8 mode)
{
  TA_ErrCode_t r = TA_Success;
  TA_Element_t* pElem;
  TA_Blk_t blkHdr;
  TA_Blk_t* pBlk = NULL;
  boolean readOk;
  int i;
    
  if(ta.mode != 0)
  {
    //The TA is already open.
    return TA_Error;
  }

  if(mode == 0)
  {
    //Can't open the TA without specifying a working mode.
    return TA_Parameters;
  }

  if((mode & TA_RAM_WRITE) && (mode & TA_SAFE_WRITE))
  {
    //We can't handle both modes simultanously.
    return TA_Parameters;
  }

  //Initiate and validate the externally implemented functions.
  if((mode & TA_READ) &&
     (taFunc.ReadBlock  == NULL ||
      taFunc.IsBadBlock == NULL ||
      taFunc.Malloc     == NULL ||
      taFunc.Free       == NULL))
  {
    return TA_Configuration;
  }
  if((mode & (TA_RAM_WRITE | TA_SAFE_WRITE)) &&
     (taFunc.ReadBlock  == NULL ||
      taFunc.WriteBlock == NULL ||
      taFunc.EraseBlock == NULL ||
      taFunc.IsBadBlock == NULL ||
      taFunc.Malloc     == NULL ||
      taFunc.Free       == NULL))
  {
    return TA_Configuration;
  }

  //Initiate the ta structure
  ta.mode      = mode;
  ta.partition = partition;
  ta.version   = 0;
  ta.usedBlks  = 0;
  ta.scrAddr   = 0xB00BB00B;
  ta.pIncElem  = NULL;
  ta.pIncUnit  = NULL;

  pUsedList = ListCreate(); 
  pFreeList = ListCreate();

  if(pUsedList == NULL ||
     pFreeList == NULL )
  {
    TA_Free(pUsedList);
    TA_Free(pFreeList);

    return TA_Memory;
  }

  //Scan the blocks that's available, and try to find valid TA blocks (correct
  //magic signature and checksum). The non valid blocks can/will later be used 
  //as scratch blocks or blocks to store TA units when more space is required. 
  for(i=0; i<ta.nbrOfBlks; i++)
  {
    if(!TA_IsBadBlock(ta.startAddr + ta.eBlkSize*i))
    {
      /* 
       * Previously the return value from TA_ReadBlock was ignored and 
       * the verification relied on the internal TA checksum only.
       *
       * Now the return value is considered due to a NAND problem:
       * - If a program is aborted at a late stage due to e.g. power loss,
       *  then the block may read correctly but be unstable and later fail.
       *  I.e. the TA check sum may be correct but the block is unstable.
       *  The driver may however contain logic to detect this condition and 
       *  return error upon read. 
       * Hence, a read error is considered equal to an error in the checksum.
       *
       * Since the return value is considered it is important that the 
       * driver does not return an error when it encounters a correctable 
       * error (e.g. 1 bit ECC error).
       */
      
      //Read the block header
      readOk = TA_ReadBlock(ta.startAddr + ta.eBlkSize*i, &blkHdr, sizeof(TA_Blk_t));

      // If the block header is OK read the whole block.
      if (readOk && blkHdr.magic == TA_MAGIC)
      {
        pBlk = TA_Malloc(BlkGetUsedSize(&blkHdr));
        
        if(pBlk == NULL)
        {
          r = TA_Memory;
          break;
        }
        
        readOk = TA_ReadBlock(ta.startAddr + ta.eBlkSize*i, pBlk, BlkGetUsedSize(&blkHdr));
      }

      // Calculate checksum of the block and verify against header
      if (readOk && 
          (blkHdr.magic == TA_MAGIC) && 
          (blkHdr.chkSum == TA_CheckSum(pBlk)) &&
          TA_IsVersionSupported(pBlk->version))
      {
        //If the block belong to our partition, we read and use it, otherwise 
        //we just ignore it.
        if(ta.partition == pBlk->partition)
        {
          pElem = ListAllocElem();

          if(pElem == NULL)
          {
            r = TA_Memory;
            break;
          }

          pElem->addr = ta.startAddr + ta.eBlkSize*i;
          pElem->pBlk = pBlk;
          pBlk = NULL;

          ListAddLast(pUsedList, pElem);
          ta.usedBlks++;
        }
      }
      else
      {
        //Here we just add the blocks to our "free list" that contains all the 
        //blocks currently not used, that may later on be filled with a valid
        //TA block. We don't care if they're blocks that behave like bad blocks, 
        //or not here (factory bad blocks is not included in the list though), 
        //instead that will be sorted out when we try to use/allocate a block 
        //from this list later (in TA_Write).

        pElem = ListAllocElem();

        if(pElem == NULL)
        {
          r = TA_Memory;
          break;
        }

        pElem->addr = ta.startAddr + ta.eBlkSize*i;
        ListAddLast(pFreeList, pElem);
      }

      if(pBlk != NULL)
      {
        TA_Free(pBlk);
      }
    }
  }

  if(r == TA_Success)
  {
    CrashRecovery();
  }

  if(r == TA_Success)
  {
    //Check if there's any valid TA data available.
    pElem = ListGetFirst(pUsedList);
    if(pElem != NULL)
    {
      ta.isValid = TRUE;
      ta.version = pElem->pBlk->version;

      //Initiate data for the incremental functions.
      TA_Inc_NextUnit(); 
    }
    else
    {
      //No valid blocks found. Return TA_Invalid, and let the
      //user verify the input data, or format the TA.
      r = TA_Invalid;
      ta.isValid = FALSE;
    }
  }

  if(r != TA_Success && r != TA_Invalid)
  {
    //An error has occured, so we return the resources used so far.
    TA_Close();
  }

  return r;
}



TA_ErrCode_t TA_GetVersion(uint8* pVersion, uint8 partition)
{
  int i;
  TA_Blk_t blkHdr;
  TA_ErrCode_t r = TA_Success;

  *pVersion = 0;

  if(ta.nbrOfBlks == 0)
  {
    return TA_Configuration;
  }

  if(ta.isValid && (ta.partition == partition))
  {
    //The partition is open, so we use the data in RAM.
    *pVersion = ta.version;
  }
  else
  {
    for(i=0; i<ta.nbrOfBlks; i++)
    {
      if (TA_ReadBlock(ta.startAddr + i*ta.eBlkSize, &blkHdr, sizeof(TA_Blk_t)) &&
          blkHdr.magic == TA_MAGIC && blkHdr.partition == partition)
      {
        *pVersion = blkHdr.version;
        break;
      }
    }
  }

  return r;
}


boolean TA_IsVersionSupported(uint8 version)
{
  //Current implementation supports v1 and v2.
  return (boolean) ( 0 < (version) && (version) <= 2 );   
}


TA_ErrCode_t TA_Format(uint8 version)
{
  TA_ErrCode_t r = TA_Success;
  TA_Element_t* pElem;

  if(!(ta.mode & (TA_RAM_WRITE | TA_SAFE_WRITE)) || ta.mode == 0)
  {
    return TA_Permission;
  }

  if(!TA_IsVersionSupported(version))
  {
    //Requested version is not supported by this implementation.
    return TA_Version;
  }

  //Add all used blocks to our free list.
  pElem = ListGetFirst(pUsedList);

  while(pElem != NULL)
  {
    pElem = ListUnlink(pUsedList, pElem);
    TA_Free(pElem->pBlk);
    ListAddLast(pFreeList, pElem);

    pElem = ListGetFirst(pUsedList);
  }

  //We have to erase ALL free blocks, since they could contain valid TA data
  //in unsupported formats (we don't want to leave any residue).
  pElem = ListGetFirst(pFreeList);

  while(pElem != NULL)
  {
    TA_EraseBlock(pElem->addr);
    pElem = ListGetNext(pFreeList, pElem);
  }

  ta.usedBlks = 0;

  pElem = ListUnlink(pFreeList, ListGetFirst(pFreeList));

  if(pElem != NULL)
  {
    pElem->pBlk = BlkAlloc(version);

    if(pElem->pBlk != NULL)
    {
      ListAddLast(pUsedList, pElem);
      r = BlkWrite(pElem);
    }
    else
    {
      r = TA_Memory;
    }
  }
  else
  {
    //Apparently there's no functional blocks available...
    r = TA_FlashMemory;
  }

  if(r == TA_Success)
  {
    ta.isValid = TRUE;
    ta.version = version;
  }

  return r;
}


TA_ErrCode_t TA_Close(void)
{
  ListDestroy(pUsedList);
  pUsedList = NULL;

  ListDestroy(pFreeList);
  pFreeList = NULL;

  ta.mode    = 0;
  ta.isValid = FALSE;

  return TA_Success;
}


TA_ErrCode_t TA_Flush(void)
{
  TA_ErrCode_t r = TA_Success;
  TA_Element_t* pElem;

  if(!ta.isValid)
  {
    return TA_Invalid;
  }

  if(!(ta.mode & TA_RAM_WRITE))
  {
    return TA_Permission;
  }

  pElem = ListGetFirst(pUsedList);
  while(pElem != NULL)
  {
    if(BlkWrite(pElem) != TA_Success)
    {
      r = TA_Error;
      break;
    }
    pElem = ListGetNext(pUsedList, pElem);
  }

  return r;
}


TA_ErrCode_t TA_WriteData(uint32 unit, const uint8* pData, uint32 size)
{
  TA_ErrCode_t r = TA_Success;
  TA_Element_t* pElem; 
  TA_Unit_t* pUnit;
  TA_Element_t* pErasedElem = NULL;

  if(!ta.isValid)
  {
    return TA_Invalid;
  }

  if(!(ta.mode & (TA_RAM_WRITE | TA_SAFE_WRITE)))
  {
    return TA_Permission;
  }

  //First check if the unit is already present and handle that case.
  if((pUnit = FindUnit(unit, NULL, NULL, &pElem)) != NULL)
  {
    if(size == pUnit->size)
    {
      //Same size as before. Just overwrite the unit and exit.
      mlc_memcpy(pUnit->data, pData, size);

      if(ta.mode & TA_SAFE_WRITE)
      {
        r = BlkWrite(pElem);
      }
      return r;
    }
    else
    {
      //Remove Unit & Compact Block
      BlkEraseUnit(pElem->pBlk, pUnit);
      //todo: Explain how we can end up with changes in two blocks etc.
      pErasedElem = pElem;
    }
  }

  pElem = ListGetFirst(pUsedList);
  while(pElem != NULL)
  {
    TA_ErrCode_t rTmp;

    rTmp = BlkWriteUnit(pElem, unit, pData, size);
    if(rTmp == TA_Success || rTmp == TA_Memory)
    {
      // Either we have been successful in writing our unit, or we're having
      // problems allocating more RAM. If we're experiencing the later, it's
      // better to abort here anyway since we otherwise may end up allocating a 
      // new flash block, even though we've run out of RAM.
      r = rTmp;
      break;
    }
    pElem = ListGetNext(pUsedList, pElem);
  }

  if(r == TA_Success && pElem == NULL)
  {
    //We haven't found space for our unit. Lets see if there's any
    //free/unused blocks that we can allocate.
    pElem = ListUnlink(pFreeList, ListGetFirst(pFreeList));

    if(pElem != NULL)
    {
      pElem->pBlk = BlkAlloc(ta.version);
      
      if(pElem->pBlk != NULL)
      {
        ListAddLast(pUsedList, pElem);
        r = BlkWriteUnit(pElem, unit, pData, size);
      }
      else
      {
        r = TA_Memory;
      }
    }
    else
    {
      r = TA_Error;
    }
  }

  if((r == TA_Success) && (ta.mode & TA_SAFE_WRITE))
  {
    //Time to write the block data to flash
    r = BlkWrite(pElem);
    
    if( (pErasedElem != NULL) && (pErasedElem != pElem)  && (r == TA_Success) )
    {
      //The change span two blocks, so we have to write down the block where
      //the unit was erased aswell.
      r = BlkWrite(pErasedElem);
    }
  }

  return r;
}


TA_ErrCode_t TA_ReadData(uint32 unit, uint8* pData, uint32 size)
{
  TA_ErrCode_t r = TA_Success;
  TA_Unit_t* pUnit;
  TA_Element_t* pElem;

  if(!ta.isValid)
  {
    return TA_Invalid;
  }

  if(!(ta.mode & TA_READ))
  {
    return TA_Permission;
  }

  pUnit = FindUnit(unit, NULL, NULL, &pElem);

  if(pUnit != NULL)
  {
    if(pUnit->size == size)
    {
      mlc_memcpy(pData, pUnit->data, pUnit->size);
    }
    else
    {
      r = TA_Parameters;
    }
  }
  else
  {
    r = TA_UnitNotFound;
  }

  return r;
}


uint32 TA_GetUnitSize(uint32 unit)
{
  TA_Unit_t* pUnit;
  TA_Element_t* pElem;

  if(!ta.isValid)
  {
    return 0;
  }

  pUnit = FindUnit(unit, NULL, NULL, &pElem);

  if(pUnit != NULL)
  {
    return pUnit->size;
  }

  return 0;
}


TA_ErrCode_t TA_DeleteUnit(uint32 unit)
{
  TA_ErrCode_t r = TA_Success;
  TA_Unit_t* pUnit;
  TA_Element_t* pElem;

  if(!ta.isValid)
  {
    return TA_Invalid;
  }

  if(!(ta.mode & (TA_RAM_WRITE | TA_SAFE_WRITE)))
  {
    return TA_Permission;
  }

  pUnit = FindUnit(unit, NULL, NULL, &pElem);

  if(pUnit != NULL)
  {
    r = BlkEraseUnit(pElem->pBlk, pUnit);
  }
  else
  {
    r = TA_UnitNotFound;
  }

  if((ta.mode & TA_SAFE_WRITE) && (r == TA_Success))
  {
    r = BlkWrite(pElem);
  }

  return r;
}


//========================
//= Incremental Functions
//========================
//Get the size of the current unit
TA_ErrCode_t TA_Inc_GetSize(uint32* pSize)
{
  if(!ta.isValid)
  {
    return TA_Invalid;
  }

  if(ta.mode & (TA_RAM_WRITE | TA_SAFE_WRITE))
  {
    return TA_Permission;
  }

  if(ta.pIncUnit == NULL)
  {
    return TA_UnitNotFound;
  }

  *pSize = ta.pIncUnit->size;

  return TA_Success; 
}


//Read the current unit.
TA_ErrCode_t TA_Inc_Read(uint32* pUnit, uint8* pData, uint32 size)
{
  if(!ta.isValid)
  {
    return TA_Invalid;
  }

  if(ta.mode & (TA_RAM_WRITE | TA_SAFE_WRITE))
  {
    return TA_Permission;
  }

  if(ta.pIncUnit == NULL)
  {
    return TA_UnitNotFound;
  }

  if(ta.pIncUnit->size > size)
  {
    return TA_Parameters;
  }

  *pUnit = ta.pIncUnit->unit;
  mlc_memcpy(pData, ta.pIncUnit->data, ta.pIncUnit->size);

  return TA_Success; 
}


//Point out the next unit in the list.
TA_ErrCode_t TA_Inc_NextUnit(void)
{
  TA_ErrCode_t r = TA_Success;

  if(!ta.isValid)
  {
    return TA_Invalid;
  }

  if(ta.mode & (TA_RAM_WRITE | TA_SAFE_WRITE))
  {
    return TA_Permission;
  }


  if(ta.pIncElem == NULL)
  {
    // Either the first time the function is called (the inc variables are 
    // initiated in TA_Open by calling this function), or we have reached the
    // end and should reset the variables again.
    ta.pIncElem = ListGetFirst(pUsedList);
    ta.pIncUnit = BlkGetFirstUnit(ta.pIncElem->pBlk);
  }
  else if(ta.pIncUnit != NULL)
  {
    ta.pIncUnit =  BlkGetNextUnit(ta.pIncElem->pBlk, ta.pIncUnit);
  }

  if(ta.pIncUnit == NULL)
  {
    while(ta.pIncUnit == NULL && ta.pIncElem != NULL)
    {
      ta.pIncElem = ListGetNext(pUsedList, ta.pIncElem);

      if(ta.pIncElem != NULL)
      {
        ta.pIncUnit = BlkGetFirstUnit(ta.pIncElem->pBlk);
      }
    }
  }

  if(ta.pIncUnit == NULL)
  {
    r = TA_UnitNotFound;
  }

  return r; 
}


//============================================================================
//= Private Functions
//============================================================================
//Search the pUsedList for the given unit.
//unit: Which unit to search for.
//pStartElem : Which element to start the search from. NULL -> First element.
//pStartUnit : Which unit to start the search from. NULL -> First unit.
static TA_Unit_t* FindUnit(uint32 unit,
                           TA_Element_t* pStartElem,
                           TA_Unit_t* pStartUnit,
                           TA_Element_t** ppFoundInElem)
{
  TA_Element_t* pElem;
  TA_Unit_t* pUnit;

  *ppFoundInElem = NULL;

  if(pStartElem == NULL)
  {
    pStartElem = ListGetFirst(pUsedList);
  }

  if(pStartElem != NULL && pStartUnit == NULL)
  {
    pStartUnit = BlkGetFirstUnit(pStartElem->pBlk);
  }

  pElem = pStartElem;
  pUnit = pStartUnit;

  while(pElem != NULL)
  {
    pUnit = BlkFindUnit(pElem->pBlk, pUnit, unit);

    if(pUnit != NULL)
    {
      *ppFoundInElem = pElem;
      break;
    }
    pElem = ListGetNext(pUsedList, pElem);
  }

  return pUnit;
}


//--- Block Handling ---
static TA_Blk_t* BlkAlloc(uint8 version)
{
  TA_Blk_t* pBlk;
  uint32    initialSize;
  
  if(version == 2)
  {
    initialSize = TAG;
  }
  else
  {
    initialSize = ta.eBlkSize;
  }

  pBlk = TA_Malloc(initialSize);

  if(pBlk != NULL)
  {
    mlc_memset(pBlk, 0xFF, initialSize);

    pBlk->blkNbr    = ta.usedBlks;
    pBlk->magic     = TA_MAGIC;
    pBlk->version   = version;
    pBlk->partition = ta.partition;
    BlkSetUsedSize(pBlk, initialSize);

    ta.usedBlks++;
  }

  return pBlk;
}


static TA_Unit_t* BlkFindUnit(TA_Blk_t* pBlk, 
                              TA_Unit_t* pStartUnit, 
                              uint32 unit)
{
  TA_Unit_t* pUnit = pStartUnit;

  if(pUnit == NULL)
  {
    pUnit = BlkGetFirstUnit(pBlk);
  }
  
  while(pUnit != NULL)
  {
    if(pUnit->unit == unit)
    {
      break;
    }
    pUnit = BlkGetNextUnit(pBlk, pUnit);
  }

  return pUnit;
}

//Returns:
//TA_Memory      -> Allocation of RAM failed.
//TA_FlashMemory -> Not enough space in current block.
static TA_ErrCode_t BlkWriteUnit(TA_Element_t* pElem, 
                                 uint32 unit, 
                                 const uint8* pData, 
                                 int size)
{
  TA_Blk_t* pBlk       = pElem->pBlk;
  TA_ErrCode_t r       = TA_Success;
  TA_Unit_t* pUnit     = NULL;
  TA_Unit_t* pUnitNext = BlkGetFirstUnit(pBlk);
  uint32 totUnitSize;

  //Traverse the list and find the free space.
  //When we exit the loop, pUnit will point to the last valid unit.
  while(pUnitNext != NULL)
  {
    pUnit     = pUnitNext;
    pUnitNext = BlkGetNextUnit(pBlk, pUnit);
  }

  //Make pUnit point to the intended location of our new unit.
  if(pUnit != NULL)
  {
    pUnit = (TA_Unit_t*)((uint8*)pUnit + UnitSize(pUnit));
  }
  else
  {
    //No valid units in the block. Just point out the first valid location.
    pUnit = (TA_Unit_t*) pBlk->data;
  }

  //Is there enough room in the physical block for our new unit?
  totUnitSize = sizeof(TA_Unit_t) + RealDataSize(size);
  if((uint32)pUnit + totUnitSize <= (uint32)pBlk + ta.eBlkSize)
  {
    //Do we need to allocate more memory to accomodate our new unit?
    if((uint32)pUnit + totUnitSize > (uint32)pBlk + BlkGetUsedSize(pBlk))
    {
      TA_Blk_t* pNewBlk;
      uint32 newSize = (((uint32)pUnit - (uint32)pBlk + totUnitSize)/TAG+1)*TAG;

      if(newSize > 0xFF*TAG)
      {
#if (TA_VERSION > 2)
#error Warning: Still compliant with current version?
#endif
        //pBlk->used = 0xFF -> eBlkSize
        newSize = ta.eBlkSize;
      }

      pNewBlk = TA_Malloc(newSize);

      if(pNewBlk != NULL)
      {
        mlc_memset(pNewBlk, 0xFF, newSize);
        mlc_memcpy(pNewBlk, pBlk, BlkGetUsedSize(pBlk));
        BlkSetUsedSize(pNewBlk, newSize);  

        //Make sure pUnit is pointing to the new memory area
        pUnit = (TA_Unit_t*) ((uint32)pNewBlk + (uint32)pUnit - (uint32)pBlk);

        TA_Free(pBlk);
        pElem->pBlk = pNewBlk;
        pBlk = pNewBlk;
      }
      else
      {
        r = TA_Memory;
      }
    }

    if(r == TA_Success)
    {
      pUnit->unit  = unit;
      pUnit->size  = size;
      pUnit->magic = TA_MAGIC;
      mlc_memcpy(pUnit->data, pData, size); 
    }
  }
  else
  {
    r = TA_FlashMemory;
  }

  return r;
}


//Remove unit, and compact the the block.
static TA_ErrCode_t BlkEraseUnit(TA_Blk_t* pBlk, TA_Unit_t* pUnit)
{
  TA_Unit_t* p1 = pUnit;
  TA_Unit_t* p2 = BlkGetNextUnit(pBlk, pUnit);
  uint32 size = 0;
  uint32 eraseSize = UnitSize(pUnit);

  //Make p1 point to the last unit.
  while(p2 != NULL)
  {
    p1 = p2;
    p2 = BlkGetNextUnit(pBlk, p1);
  }

  if(p1 != pUnit)
  {
    p2 = BlkGetNextUnit(pBlk, pUnit);
    size = (uint32)p1 + UnitSize(p1) - (uint32)p2;
    mlc_memmove(pUnit, p2, size);
  }

  //We "erase" the area after our current last unit, so we don't leave
  //any MAGIC numbers behind that can later cause problems for us.
  //pUnit + size = end of data in the block.
  mlc_memset((uint8*)pUnit + size, 0xFF, eraseSize);

  if(pBlk->version != 1)
  {
    //Only valid for other versions than v1!
    //Update used size, in case it's been changed.
    BlkSetUsedSize(pBlk, (uint32)pUnit + size - (uint32)pBlk);
  }
  
  return TA_Success;
}


static TA_Unit_t* BlkGetFirstUnit(TA_Blk_t* pBlk)
{
  TA_Unit_t* pUnit = (TA_Unit_t*) pBlk->data;

  if(pUnit->magic != TA_MAGIC)
  {
    pUnit = NULL;
  }

  return pUnit;
}


static TA_Unit_t* BlkGetNextUnit(TA_Blk_t* pBlk, TA_Unit_t* pUnit)
{
  TA_Unit_t* pNextUnit = (TA_Unit_t*)((uint8*)pUnit + UnitSize(pUnit));

  //If there's enough free space in the block for a TA Unit Header, we read
  //the header (magic) to see if it's a valid unit. If not, we return NULL.
  if((uint32)pNextUnit + sizeof(TA_Unit_t) <= (uint32)pBlk + BlkGetUsedSize(pBlk) &&
     pNextUnit->magic == TA_MAGIC)
  {
    return pNextUnit;
  }

  return NULL;
}


//32-bit Aligned Data Size
static int RealDataSize(uint32 inSize)
{
  int align = inSize & 3;
  int size = inSize & 0xFFFFFFFC; 

  if(align)
  {
    size += 4; //32bit aligned.
  }

  return size;
}


static TA_ErrCode_t BlkWrite(TA_Element_t* pElem)
{
  TA_ErrCode_t r = TA_Success;
  TA_Element_t* pFreeElem;
  uint32 tmpAddr;

  pElem->pBlk->chkSum = TA_CheckSum(pElem->pBlk);

  if(ta.scrAddr == 0xB00BB00B)
  {
    //Allocate a scratch block.
    TA_Element_t* pE = ListUnlink(pFreeList, ListGetFirst(pFreeList));

    if(pE != NULL)
    {
      ta.scrAddr = pE->addr;
      TA_EraseBlock(ta.scrAddr);
      TA_Free(pE);
    }
    else
    {
      r = TA_FlashMemory;
    }
  }

  if(r == TA_Success)
  {
    while(!TA_WriteBlock(ta.scrAddr, pElem->pBlk, BlkGetUsedSize(pElem->pBlk)))
    {
      //Erase the block that couldn't be successfully written, to avoid problems
      //when we open the TA the next time. For pCore, single bit errors can be
      //reported as an error when you write it, but that will actually be corrected
      //when you read back the data.
      TA_EraseBlock(ta.scrAddr);

      pFreeElem = ListUnlink(pFreeList, ListGetFirst(pFreeList));

      if(pFreeElem != NULL)
      {
        //Steal the address, and try again
        ta.scrAddr = pFreeElem->addr;
        TA_EraseBlock(ta.scrAddr);
        TA_Free(pFreeElem);
      }
      else
      {
        r = TA_FlashMemory;
        break;
      }
    }
  }

  if(r == TA_Success)
  {
    //Erase the old data
    TA_EraseBlock(pElem->addr);
    tmpAddr     = pElem->addr;
    pElem->addr = ta.scrAddr;
    ta.scrAddr  = tmpAddr;
  }

  return r;
}



//1) Find double blocks, and remove one of them.
//2) Find double units, and remove one of them.
//todo: Can't in rare, and unlikely, cases recover from a crash that was 
//      caused while the other partition was active (if a double block now 
//      occupy the "only free block left").
static void CrashRecovery(void)
{
  TA_Element_t* pElem1;
  TA_Element_t* pElem2;
  TA_Unit_t* pUnit1;
  boolean foundDouble = FALSE;

  pElem1 = ListGetFirst(pUsedList);

  //Search for block doubles.
  while(pElem1 != NULL && !foundDouble)
  {
    pElem2 = ListGetNext(pUsedList, pElem1);

    while(pElem2 != NULL && !foundDouble)
    {
      if(pElem1->pBlk->blkNbr == pElem2->pBlk->blkNbr)
      {
        foundDouble = TRUE;
        break;
      }
      pElem2 = ListGetNext(pUsedList, pElem2);
    }
    pElem1 = ListGetNext(pUsedList, pElem1);
  }

  if(foundDouble)
  {
    //Remove double and add it to the free list
    TA_EraseBlock(pElem2->addr);
    //Deallocate the block and add it to the free list
    pElem2 = ListUnlink(pUsedList, pElem2);
    TA_Free(pElem2->pBlk);
    ListAddLast(pFreeList, pElem2);
    ta.usedBlks--;
  }

  //Double Units?
  //Note: We don't have to search for doubles in the same block.
  foundDouble = FALSE;
  pUnit1 = NULL;
  pElem1 = ListGetFirst(pUsedList); 
  pElem2 = NULL;

  if(pElem1 != NULL)
  {
    pUnit1 = BlkGetFirstUnit(pElem1->pBlk);
    pElem2 = ListGetNext(pUsedList, pElem1);
  }

  while(pElem2 != NULL)
  {
    if(FindUnit(pUnit1->unit, pElem2,NULL, &pElem2)) 
    {
      //Erase the (double) unit!
      BlkEraseUnit(pElem1->pBlk, pUnit1);
      //Write the "corrected" block
      BlkWrite(pElem1);
      break;
    }

    pUnit1 = BlkGetNextUnit(pElem1->pBlk, pUnit1);

    if(pUnit1 == NULL)
    {
      //Get the first unit from the next block, if any.
      pElem1 = ListGetNext(pUsedList, pElem1);
      if(pElem1 != NULL)
      {
        pUnit1 = BlkGetFirstUnit(pElem1->pBlk);
      }
    }
    pElem2 = ListGetNext(pUsedList, pElem1);
  }
}


//--- DL-List functions ---
static TA_Element_t* ListAllocElem(void)
{
  TA_Element_t* pElem = TA_Malloc(sizeof(TA_Element_t));

  if(pElem != NULL)
  {
    pElem->pNext = NULL;
    pElem->pPrev = NULL;
    pElem->addr  = 0xB00BB00B;
    pElem->pBlk  = NULL;
  }

  return pElem;
}


static TA_Element_t* ListCreate(void)
{
  TA_Element_t* pElem = ListAllocElem();

  if(pElem != NULL)
  {
    pElem->pNext = pElem;
    pElem->pPrev = pElem;
  }

  return pElem;
}


//Free the elements in the list, aswell as the memory allocated for the 
//data (if any)
static void ListDestroy(TA_Element_t *pList)
{
  TA_Element_t* pElem;
  
  if(pList == NULL)
  {
    return;
  }

  pElem = pList->pNext;

  while(pElem != pList)
  {
    pElem = pElem->pNext;
    TA_Free(pElem->pPrev->pBlk); 
    TA_Free(pElem->pPrev);
  }

  TA_Free(pElem);
}


static void ListAddLast(TA_Element_t* pList, 
                        TA_Element_t* pElem)
{
  pElem->pNext = pList;
  pElem->pPrev = pList->pPrev;

  pList->pPrev->pNext = pElem;
  pList->pPrev        = pElem;
}


//todo: either remove pList, or check that the element is part of the list.
static TA_Element_t* ListUnlink(TA_Element_t* pList,
                                TA_Element_t* pElem)
{
  if(pList == NULL || pElem == NULL)
  {
    return NULL;
  }

  if(pList == pElem)
  {
    return NULL;
  }

  pElem->pNext->pPrev = pElem->pPrev;
  pElem->pPrev->pNext = pElem->pNext;

  pElem->pNext = NULL;
  pElem->pPrev = NULL;

  return pElem;
}


static TA_Element_t* ListGetFirst(TA_Element_t* pList)
{
  if(pList->pNext != pList)
  {
    return pList->pNext;
  }
  else
  {
    return NULL;
  }
}


static TA_Element_t* ListGetNext(TA_Element_t* pList, 
                                 TA_Element_t* pElem)
{
  if(pList == NULL || pElem == NULL)
  {
    return NULL;
  }

  if(pElem->pNext != pList)
  {
    return pElem->pNext;
  }
  else
  {
    return NULL;
  }
}


// TA_CheckSum will return an Adler32 checksum.
#define ADLER_BASE 65521 
static uint32 TA_CheckSum(TA_Blk_t* pBlk)
{
  uint32 s1   = 1;
  uint32 s2   = 0;
  uint8* pBuf = (uint8*)pBlk + sizeof(pBlk->magic) + sizeof(pBlk->chkSum);
  uint32 len  = BlkGetUsedSize(pBlk) - sizeof(pBlk->magic) - sizeof(pBlk->chkSum);

  while(len)
  {
    int tlen = len > 5552 ? 5552 : len;
    len -= tlen;

    while(tlen)
    {
      s1 += *pBuf++;
      s2 += s1;
      tlen--;
    }

    // It's enough to calculate the modulo every 5552 turn.
    s1 = s1 % ADLER_BASE;
    s2 = s2 % ADLER_BASE;
  }

  return (s2 << 16) + s1;
}


//BlkGetUsedSize returns the amount of data in the block that's used.
static uint32 BlkGetUsedSize(TA_Blk_t* pBlk)
{
  if(pBlk->used == 0xFF)
  {
    return ta.eBlkSize;
  }
  else
  {
    return (pBlk->used + 1) * TAG;
  }
}

//BlkSetUsedSize set the used parameter in the block info. If size is too
//big to fit in 'used' (size > 0xFF*TAG), used will be set to 0xFF. 
static void BlkSetUsedSize(TA_Blk_t* pBlk, 
                           uint32 size)
{
  if(size <= 0xFF*TAG)
  {
    pBlk->used = (uint8) ((size - 1) / TAG); 
  }
  else
  {
    pBlk->used = 0xFF;
  }
}


#ifdef CFG_TA_DEBUG
void TA_Dbg_InspectBlocks(uint32 *status, uint32 *partition, uint32 *version)
{
  TA_Blk_t blkHdr;
  TA_Blk_t* pBlk;
  boolean readOk;
  uint32 chkSum;
  int i;
    
  for (i = 0; i < ta.nbrOfBlks; i++)
  {
    // Check if bad block
    if (TA_IsBadBlock(ta.startAddr + ta.eBlkSize*i))
    {
      status[i] = TA_Dbg_BadBlock;
      continue;
    }
	  
    // Read header
    readOk = TA_ReadBlock(ta.startAddr + ta.eBlkSize*i, &blkHdr, sizeof(TA_Blk_t));
    if (!readOk)
    {
      status[i] = TA_Dbg_ReadHeaderFail;
      continue;
    }

    // Check magic
    if (blkHdr.magic != TA_MAGIC)
    {
      status[i] = TA_Dbg_MagicMismatch;
      partition[i] = blkHdr.magic;
      continue;
    }

    pBlk = TA_Malloc(BlkGetUsedSize(&blkHdr));

    // Read block
    readOk = TA_ReadBlock(ta.startAddr + ta.eBlkSize*i, pBlk, BlkGetUsedSize(&blkHdr));
    if (!readOk)
    {
      status[i] = TA_Dbg_ReadBlockFail;
      TA_Free(pBlk);
      continue;
    }

    // Check checksum
    chkSum = TA_CheckSum(pBlk);
    if (chkSum != blkHdr.chkSum)
    {
      status[i] = TA_Dbg_ChksumMismatch;
      partition[i] = blkHdr.chkSum;
      TA_Free(pBlk);
      continue;
    }

    status[i] = TA_Dbg_Valid;
    partition[i] = pBlk->partition;
    version[i] = pBlk->version;

    TA_Free(pBlk);
  }
}
#endif

