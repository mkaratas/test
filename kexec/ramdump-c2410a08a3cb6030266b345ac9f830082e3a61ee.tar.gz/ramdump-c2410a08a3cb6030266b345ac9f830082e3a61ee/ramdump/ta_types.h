/*********************************************************************
 *  ____                      _____      _                           *
 * / ___|  ___  _ __  _   _  | ____|_ __(_) ___ ___ ___  ___  _ __   *
 * \___ \ / _ \| '_ \| | | | |  _| | '__| |/ __/ __/ __|/ _ \| '_ \  *
 *  ___) | (_) | | | | |_| | | |___| |  | | (__\__ \__ \ (_) | | | | *
 * |____/ \___/|_| |_|\__, | |_____|_|  |_|\___|___/___/\___/|_| |_| *
 *                    |___/                                          *
 *                                                                   *
 *********************************************************************
 * Copyright 2006-2009 Sony Ericsson Mobile Communications AB.       *
 * All rights, including trade secret rights, reserved.              *
 *********************************************************************/

/***  IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT  ***
 *                                                                   *
 * All changes to the Trim Area implementation must be cleared with  *
 * Flash Core Security (the loader developers) in order to ensure    *
 * that the loaders stay functional after a change.                  *
 *                                                                   *
 * Failure to do so may incur severe costs for the company due to    *
 * halted or faulty production.                                      *
 *                                                                   *
 * Signed: Hans Wachtmeister (Loader MA) 2009-03-30                  *
 *                                                                   *
 ***  IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT  ***/

/**
 * @file ta_types.h
 *
 * @brief Trim Area (TA) type definitions
 *
 * @ingroup TA
 *
 * @copyright 2006-2009, Sony Ericsson Mobile Communications AB
 *
 * @responsible Jens-Henrik Lindskov (jens-henrik.lindskov@sonyericsson.com)
 *
 * @todo 
 *
 * @review
 */
#ifndef INCLUSION_GUARD_TA_TYPES
#define INCLUSION_GUARD_TA_TYPES

#include "types.h"

//#define CFG_TA_EXTERNAL_BUILD
#ifdef CFG_TA_EXTERNAL_BUILD
  /** Type definition for an unsigned 8 bit data entity. */
  typedef unsigned char uint8;

  /** Type definition for an unsigned 16 bit data entity. */
  typedef unsigned short uint16;

  /** Type definition for an unsigned 32 bit data entity. */
  typedef unsigned long uint32;

  /** Type definition for a boolean/logical value */
  typedef uint8 boolean;

  #ifndef TRUE
    /** Value representing the boolean/logical value false. */
    #define FALSE 0
    /** Value representing the boolean/logical value true. */
    #define TRUE (!FALSE)
  #endif
#else
//  #include "t_basicdefinitions.h"
#endif


/// @name Defines
//@{
typedef enum
{
  TA_Success, 
  TA_Error,         //General error
  TA_Version,       //Non compliant version
  TA_Memory,        //Memory related error 
  TA_UnitNotFound,  //Unit could not be found
  TA_Permission,    //TA opened to not support the operation
  TA_Invalid,       //TA is invalid. TA_Format may be required.
  TA_Parameters,    //Invalid parameters has been passed to the function.
  TA_FlashMemory,   //Flash related error.
  TA_UnsupportedCmd,//Not implemented/supported.
  TA_Configuration  //Configuration error.
} TA_ErrCode_t; 


//Defines to set up the mode to operate the TA in.
#define TA_READ       0x1 //Read
#define TA_RAM_WRITE  0x2 //All writes are done to RAM. A call to TA_Flush is
                          //required to actually write data to flash. If the
                          //phone crash before TA_Flush has been successfully
                          //executed, all changes will be lost. This mode 
                          //should not be used outside controlled environments
                          //such as a factory. 
#define TA_SAFE_WRITE 0x4 //On every call to TA_WriteData, the unit will be 
                          //written straight to flash. If the phone crash
                          //during a write, it will be recovered and either
                          //the old data, or the one written, will be present.
                          //This mode will cause a lot of erases/writes to 
                          //flash.


//Defines for the default partitions to handle in the TA. 
#define TA_TRIM_PART 1 //Trim Data Partition
#define TA_MISC_PART 2 //Miscellaneous Data Partition (Non Trim Data)


/*
 * The idea behind the functions that's supplied by the TA's client, is that 
 * they should abstract the type of memory media used to store the TA data. 
 * For instance, the data can be stored in NAND, NOR or written to a file,
 * as long as the interfaces between the client and the TA is kept intact.
 *
 * The TA is unaware of concepts such as spare data (redundant areas) or ECC 
 * handling. The TA only handles its own "raw data".
 */

/**
 * This function shall read the specified amount (size) of data, starting from 
 * the provided address, and copy that data to the data buffer (pData). This
 * function should include the handling of ECC whenever it is needed (NAND).
 *
 * @param[in] addr The start address.
 * @param[in] pData Pointer to the data buffer.
 * @param[in] size Specifies the requested amount of data.
 *
 * @returns TRUE for success, and FALSE if an error occured.
 */
typedef boolean(*TA_ReadBlock_t)(uint32, void*, uint32);

/**
 * This function shall write data to flash. This function should include the 
 * handling of ECC whenever it is needed (NAND). 
 
 * Note that the TA will not perform a read back to secure that the data was 
 * successfully written to the storage device, so for some devices it may be
 * advisable to include a read back to make sure that the data was written as
 * intended.
 *
 * @param[in] addr The start address.
 * @param[in] pData Pointer to the data buffer.
 * @param[in] Specifies the requested amount of data to write.
 *
 * @returns TRUE for success, and FALSE if an error occured.
 */
typedef boolean(*TA_WriteBlock_t)(uint32, void*, uint32);

/**
 * This function shall erase one flash erase block, located at the supplied
 * address. Blocks tried unsuccessfully with the function TA_IsBadBlock, will
 * not be erased by the TA.
 *
 * @param[in] addr The address of the block to be erased.
 *
 * @returns TRUE for success, and FALSE if an error occured.
 */
typedef boolean(*TA_EraseBlock_t)(uint32);

/**
 * This function shall give information whether or not a block is valid for
 * use by the TA. Blocks that is marked as bad according to this function 
 * will be completly ignored by the TA.
 * 
 * This function is mainly here to support targets with NAND memory, where
 * the client want the TA to handle its own bad block management. For targets
 * that has no need for this functionality, simply return FALSE whenever
 * this function is called from the TA.
 *
 * @param[in] addr The address of the block to be tried.
 *
 * @returns TRUE if the block is bad, and FALSE otherwise.
 */
typedef boolean(*TA_IsBadBlock_t)(uint32);

/**
 * This function should behave just like the ANSI C function 'malloc'.
 *
 * @param[in] size The size of the buffer to be allocated.
 *
 * @returns A pointer to the memory allocated, or NULL on failure.
 */
typedef void*(*TA_Malloc_t)(size_t);

/**
 * This function should behave just like the ANSI C function 'free'.
 *
 * @param[in] void* A pointer to the buffer to be freed.
 *
 * @returns void
 */
typedef void(*TA_Free_t)(void*);

//A description of each member of this struct can be found in this file.
typedef struct
{
  TA_ReadBlock_t  ReadBlock;
  TA_WriteBlock_t WriteBlock;
  TA_EraseBlock_t EraseBlock;
  TA_IsBadBlock_t IsBadBlock;
  TA_Malloc_t     Malloc;
  TA_Free_t       Free;
} TA_Functions_t;
//@} End of Defines
#endif//INCLUSION_GUARD_TA_TYPES
