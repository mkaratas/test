#pragma once

int uart_putc(char c);
